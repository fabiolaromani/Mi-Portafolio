package Modelo;

import java.util.ArrayList;

public class ProyectoModelo {
    private ArrayList<TareaModelo> listaTareas;

    public ProyectoModelo() {
        this.listaTareas = new ArrayList<>();
    }

    public ArrayList<TareaModelo> getListaTareas() {
        return listaTareas;
    }

    public void agregarTarea(TareaModelo tarea) {
        this.listaTareas.add(tarea);
    }

    // Método de apoyo para buscar una tarea por su código utilizando un bucle básico
    public TareaModelo buscarTarea(String codigo) {
        for (int i = 0; i < listaTareas.size(); i++) {
            TareaModelo t = listaTareas.get(i);
            if (t.getCodigo().equalsIgnoreCase(codigo)) {
                return t;
            }
        }
        return null;
    }
}