package Modelo;

import java.util.ArrayList;

public class TareaModelo {
    private String codigo;
    private String descripcion;
    private String estado; // Ejemplo: "Pendiente", "Completada", "Bloqueada"
    private ArrayList<String> listaPrerrequisitos; // Códigos de las tareas de las que depende

    public TareaModelo(String codigo, String descripcion, String estado) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.estado = estado;
        this.listaPrerrequisitos = new ArrayList<>();
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public ArrayList<String> getListaPrerrequisitos() {
        return listaPrerrequisitos;
    }

    public void agregarPrerrequisito(String codigoPrerrequisito) {
        this.listaPrerrequisitos.add(codigoPrerrequisito);
    }
}