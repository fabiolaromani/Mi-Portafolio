package DAO;

import Modelo.ProyectoModelo;
import Modelo.TareaModelo;
import java.util.ArrayList;

public class DependenciasDAO {

    // RF02: Registrar una dependencia entre dos tareas existentes
    public boolean registrarDependencia(ProyectoModelo proyecto, String codigoTarea, String codigoPrerrequisito) {
        TareaModelo tarea = proyecto.buscarTarea(codigoTarea);
        TareaModelo prerrequisito = proyecto.buscarTarea(codigoPrerrequisito);

        if (tarea != null && prerrequisito != null) {
            // Evitar duplicados y auto-dependencias
            if (!codigoTarea.equalsIgnoreCase(codigoPrerrequisito)) {
                ArrayList<String> prereqs = tarea.getListaPrerrequisitos();
                for (int i = 0; i < prereqs.size(); i++) {
                    if (prereqs.get(i).equalsIgnoreCase(codigoPrerrequisito)) {
                        return false; // Ya existe la dependencia
                    }
                }
                tarea.agregarPrerrequisito(codigoPrerrequisito);
                return true;
            }
        }
        return false;
    }

    // RF04: Mostrar recursivamente todas las dependencias indirectas de una tarea
    public void obtenerDependenciasIndirectas(ProyectoModelo proyecto, String codigoTarea, ArrayList<String> visitados) {
        TareaModelo tarea = proyecto.buscarTarea(codigoTarea);
        if (tarea == null) {
            return;
        }

        ArrayList<String> prereqs = tarea.getListaPrerrequisitos();
        for (int i = 0; i < prereqs.size(); i++) {
            String codigoPrereq = prereqs.get(i);
            
            // Verificar si ya fue visitado para evitar bucles infinitos en impresiones
            boolean yaVisitado = false;
            for (int j = 0; j < visitados.size(); j++) {
                if (visitados.get(j).equalsIgnoreCase(codigoPrereq)) {
                    yaVisitado = true;
                    break;
                }
            }

            if (!yaVisitado) {
                visitados.add(codigoPrereq);
                System.out.println(" -> Prerrequisito: " + codigoPrereq);
                // Llamada recursiva para explorar los prerrequisitos del prerrequisito
                obtenerDependenciasIndirectas(proyecto, codigoPrereq, visitados);
            }
        }
    }

    // RF05: Determinar la profundidad máxima de la cadena de dependencias (Recursividad)
    public int calcularProfundidad(ProyectoModelo proyecto, String codigoTarea) {
        TareaModelo tarea = proyecto.buscarTarea(codigoTarea);
        if (tarea == null || tarea.getListaPrerrequisitos().isEmpty()) {
            return 0;
        }

        int maxProfundidadPrereq = 0;
        ArrayList<String> prereqs = tarea.getListaPrerrequisitos();
        
        for (int i = 0; i < prereqs.size(); i++) {
            int profundidadActual = calcularProfundidad(proyecto, prereqs.get(i));
            if (profundidadActual > maxProfundidadPrereq) {
                maxProfundidadPrereq = profundidadActual;
            }
        }

        return 1 + maxProfundidadPrereq;
    }

    // RF06: Detectar ciclos en el grafo de dependencias usando recursividad y listas de control
    public boolean tieneCiclos(ProyectoModelo proyecto) {
        ArrayList<String> visitadosGlobales = new ArrayList<>();
        ArrayList<String> pilaRecursion = new ArrayList<>();

        ArrayList<TareaModelo> tareas = proyecto.getListaTareas();
        for (int i = 0; i < tareas.size(); i++) {
            String codigo = tareas.get(i).getCodigo();
            
            boolean yaVisitado = false;
            for (int j = 0; j < visitadosGlobales.size(); j++) {
                if (visitadosGlobales.get(j).equalsIgnoreCase(codigo)) {
                    yaVisitado = true;
                    break;
                }
            }

            if (!yaVisitado) {
                if (explorarCicloDFS(proyecto, codigo, visitadosGlobales, pilaRecursion)) {
                    return true; // Se encontró un ciclo
                }
            }
        }
        return false;
    }

    // Método auxiliar recursivo para DFS (Depth-First Search) sin usar estructuras avanzadas
    private boolean explorarCicloDFS(ProyectoModelo proyecto, String codigoActual, 
                                     ArrayList<String> visitadosGlobales, ArrayList<String> pilaRecursion) {
        visitadosGlobales.add(codigoActual);
        pilaRecursion.add(codigoActual);

        TareaModelo tarea = proyecto.buscarTarea(codigoActual);
        if (tarea != null) {
            ArrayList<String> prereqs = tarea.getListaPrerrequisitos();
            for (int i = 0; i < prereqs.size(); i++) {
                String vecino = prereqs.get(i);

                // Si el vecino está en la pila de recursión actual, hay un ciclo
                boolean enPila = false;
                for (int j = 0; j < pilaRecursion.size(); j++) {
                    if (pilaRecursion.get(j).equalsIgnoreCase(vecino)) {
                        enPila = true;
                        break;
                    }
                }
                if (enPila) {
                    return true;
                }

                // Si no ha sido visitado globalmente, explorarlo recursivamente
                boolean visitadoG = false;
                for (int j = 0; j < visitadosGlobales.size(); j++) {
                    if (visitadosGlobales.get(j).equalsIgnoreCase(vecino)) {
                        visitadoG = true;
                        break;
                    }
                }
                if (!visitadoG) {
                    if (explorarCicloDFS(proyecto, vecino, visitadosGlobales, pilaRecursion)) {
                        return true;
                    }
                }
            }
        }

        // Remover de la pila de recursión al retroceder (backtracking)
        for (int j = 0; j < pilaRecursion.size(); j++) {
            if (pilaRecursion.get(j).equalsIgnoreCase(codigoActual)) {
                pilaRecursion.remove(j);
                break;
            }
        }

        return false;
    }
}