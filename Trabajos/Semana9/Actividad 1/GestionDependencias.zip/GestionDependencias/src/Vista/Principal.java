package Vista;

public class Principal {

    public static void main(String[] args) {
        DependenciaVista vista = new DependenciaVista();
        vista.iniciar();
    }
}