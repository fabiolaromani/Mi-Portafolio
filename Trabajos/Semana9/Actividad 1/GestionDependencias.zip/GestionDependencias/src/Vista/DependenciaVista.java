package Vista;

import DAO.DependenciasDAO;
import Modelo.ProyectoModelo;
import Modelo.TareaModelo;
import java.util.ArrayList;
import java.util.Scanner;

public class DependenciaVista {

    private final Scanner teclado;
    private final DependenciasDAO dao;
    private final ProyectoModelo proyecto;

    public DependenciaVista() {
        teclado = new Scanner(System.in);
        dao = new DependenciasDAO();
        proyecto = new ProyectoModelo();
    }

    public void iniciar() {
        int opcion = 0;
        do {
            try {
                mostrarMenu();
                System.out.print("Seleccione una opcion: ");
                opcion = Integer.parseInt(teclado.nextLine());

                switch (opcion) {
                    case 1:
                        registrarTarea();
                        break;
                    case 2:
                        registrarDependencia();
                        break;
                    case 3:
                        consultarDependenciasDirectas();
                        break;
                    case 4:
                        consultarDependenciasIndirectas();
                        break;
                    case 5:
                        calcularProfundidad();
                        break;
                    case 6:
                        evaluarCiclos();
                        break;
                    case 7:
                        generarReporte();
                        break;
                    case 8:
                        System.out.println("Saliendo del sistema...");
                        break;
                    default:
                        System.out.println("Opcion invalida. Intente de nuevo.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Debe ingresar un numero entero.");
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
            System.out.println();
        } while (opcion != 8);
    }

    private void mostrarMenu() {
        System.out.println("--- SISTEMA DE GESTION DE DEPENDENCIAS ---");
        System.out.println("1. Registrar Tarea (RF01)");
        System.out.println("2. Registrar Dependencia (RF02)");
        System.out.println("3. Consultar Dependencias Directas (RF03)");
        System.out.println("4. Consultar Dependencias Indirectas (Recursivo - RF04)");
        System.out.println("5. Determinar Profundidad Maxima (RF05)");
        System.out.println("6. Detectar Ciclos en el Grafo (RF06)");
        System.out.println("7. Generar Reporte de Tareas (RF07/RF08)");
        System.out.println("8. Salir");
    }

    private void registrarTarea() {
        System.out.print("Ingrese el codigo unico de la tarea: ");
        String codigo = teclado.nextLine();

        if (proyecto.buscarTarea(codigo) != null) {
            System.out.println("Error: Ya existe una tarea con ese codigo.");
            return;
        }

        System.out.print("Ingrese la descripcion: ");
        String descripcion = teclado.nextLine();

        System.out.print("Ingrese el estado (Pendiente / Completada / Bloqueada): ");
        String estado = teclado.nextLine();

        TareaModelo nuevaTarea = new TareaModelo(codigo, descripcion, estado);
        proyecto.agregarTarea(nuevaTarea);
        System.out.println("Tarea registrada con exito.");
    }

    private void registrarDependencia() {
        System.out.print("Ingrese el codigo de la tarea principal: ");
        String codigoTarea = teclado.nextLine();

        System.out.print("Ingrese el codigo de la tarea prerrequisito (dependencia): ");
        String codigoPrereq = teclado.nextLine();

        boolean exito = dao.registrarDependencia(proyecto, codigoTarea, codigoPrereq);
        if (exito) {
            System.out.println("Dependencia registrada correctamente.");
        } else {
            System.out.println("Error: No se pudo registrar la dependencia (verifique codigos o duplicados).");
        }
    }

    private void consultarDependenciasDirectas() {
        System.out.print("Ingrese el codigo de la tarea: ");
        String codigo = teclado.nextLine();

        TareaModelo tarea = proyecto.buscarTarea(codigo);
        if (tarea == null) {
            System.out.println("Error: Tarea no encontrada.");
            return;
        }

        ArrayList<String> prereqs = tarea.getListaPrerrequisitos();
        System.out.println("Dependencias directas de " + codigo + ":");
        if (prereqs.isEmpty()) {
            System.out.println(" (Ninguna)");
        } else {
            for (int i = 0; i < prereqs.size(); i++) {
                System.out.println(" -> " + prereqs.get(i));
            }
        }
    }

    private void consultarDependenciasIndirectas() {
        System.out.print("Ingrese el codigo de la tarea a consultar: ");
        String codigo = teclado.nextLine();

        if (proyecto.buscarTarea(codigo) == null) {
            System.out.println("Error: Tarea no encontrada.");
            return;
        }

        System.out.println("Recorriendo dependencias recursivamente para: " + codigo);
        ArrayList<String> visitados = new ArrayList<>();
        dao.obtenerDependenciasIndirectas(proyecto, codigo, visitados);

        if (visitados.isEmpty()) {
            System.out.println(" (No tiene dependencias registradas)");
        }
    }

    private void calcularProfundidad() {
        System.out.print("Ingrese el codigo de la tarea: ");
        String codigo = teclado.nextLine();

        if (proyecto.buscarTarea(codigo) == null) {
            System.out.println("Error: Tarea no encontrada.");
            return;
        }

        int profundidad = dao.calcularProfundidad(proyecto, codigo);
        System.out.println("La profundidad maxima de la cadena de dependencias es: " + profundidad);
    }

    private void evaluarCiclos() {
        boolean hayCiclo = dao.tieneCiclos(proyecto);
        if (hayCiclo) {
            System.out.println("¡ALERTA! Se han detectado ciclos e inconsistencias en la planificacion.");
        } else {
            System.out.println("El grafo de dependencias es valido (no contiene ciclos).");
        }
    }

    private void generarReporte() {
        ArrayList<TareaModelo> lista = proyecto.getListaTareas();
        if (lista.isEmpty()) {
            System.out.println("No hay tareas registradas en el proyecto.");
            return;
        }

        System.out.println("\n--- REPORTE GENERAL DE TAREAS Y ESTADOS ---");
        for (int i = 0; i < lista.size(); i++) {
            TareaModelo t = lista.get(i);
            
            // Evaluar si esta bloqueada por prerrequisitos no completados
            boolean bloqueada = false;
            ArrayList<String> prereqs = t.getListaPrerrequisitos();
            for (int j = 0; j < prereqs.size(); j++) {
                TareaModelo prereqTarea = proyecto.buscarTarea(prereqs.get(j));
                if (prereqTarea != null && !prereqTarea.getEstado().equalsIgnoreCase("Completada")) {
                    bloqueada = true;
                    break;
                }
            }

            String estadoCalculado = t.getEstado();
            if (bloqueada && !t.getEstado().equalsIgnoreCase("Completada")) {
                estadoCalculado = "Bloqueada (Prerrequisitos pendientes)";
            }

            System.out.println("Codigo: " + t.getCodigo() + " | Descripcion: " + t.getDescripcion() 
                    + " | Estado: " + estadoCalculado);
        }
    }
}