package Modelo;

public class ExpresionModelo {
    private String expresionOriginal;
    private double resultado;

    public ExpresionModelo(String expresionOriginal) {
        this.expresionOriginal = expresionOriginal;
        this.resultado = 0.0;
    }

    public String getExpresionOriginal() {
        return expresionOriginal;
    }

    public void setExpresionOriginal(String expresionOriginal) {
        this.expresionOriginal = expresionOriginal;
    }

    public double getResultado() {
        return resultado;
    }

    public void setResultado(double resultado) {
        this.resultado = resultado;
    }
}