package Vista;

import DAO.EvaluadorExpresionesDAO;
import Modelo.ExpresionModelo;
import java.util.Scanner;

public class EvaluadorExpresionesVista {

    private final Scanner teclado;
    private final EvaluadorExpresionesDAO dao;

    public EvaluadorExpresionesVista() {
        teclado = new Scanner(System.in);
        dao = new EvaluadorExpresionesDAO();
    }

    public void iniciar() {
        int opcion = 0;
        do {
            System.out.println("\n--- SISTEMA DE EVALUACION DE REGLAS COMERCIALES ---");
            System.out.println("1. Evaluar expresion matematica (RF01 - RF08)");
            System.out.println("2. Salir (RF09)");
            System.out.print("Seleccione una opcion: ");

            try {
                opcion = Integer.parseInt(teclado.nextLine());

                switch (opcion) {
                    case 1:
                        procesarExpresion();
                        break;
                    case 2:
                        System.out.println("Saliendo del sistema de evaluacion...");
                        break;
                    default:
                        System.out.println("Opcion invalida. Intente de nuevo.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Debe ingresar un numero entero valido.");
            } catch (Exception e) {
                System.out.println("Error inesperado: " + e.getMessage());
            }
        } while (opcion != 2);
    }

    private void procesarExpresion() {
        System.out.print("\nIngrese la expresion matematica (ej: (50 - 5) * (1 + 0.18)): ");
        String formula = teclado.nextLine();

        ExpresionModelo modelo = new ExpresionModelo(formula);

        try {
            // Evaluamos utilizando el analizador recursivo del DAO
            double resultado = dao.evaluar(modelo.getExpresionOriginal());
            modelo.setResultado(resultado);

            // Mostrar resultados (RF05, RF08)
            System.out.println("\n--- RESULTADO DE LA EVALUACION ---");
            System.out.println("Expresion original: " + modelo.getExpresionOriginal());
            System.out.println("Resultado final: " + modelo.getResultado());
            System.out.println("Estado: Validacion y calculo exitosos (RF10).");

        } catch (Exception e) {
            System.out.println("\n[ERROR DE VALIDACION / SINTAXIS]");
            System.out.println("Detalle: " + e.getMessage());
            System.out.println("La expresion no puede ser utilizada en procesos comerciales hasta ser corregida (RF06, RF07, RF10).");
        }
    }
}