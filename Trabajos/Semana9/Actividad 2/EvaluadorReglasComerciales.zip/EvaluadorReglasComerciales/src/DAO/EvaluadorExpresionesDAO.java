package DAO;

public class EvaluadorExpresionesDAO {

    private String texto;
    private int pos;

    // Método principal de entrada para evaluar la expresión (RF01, RF05)
    public double evaluar(String expresion) throws Exception {
        // Eliminar espacios en blanco para facilitar el recorrido
        this.texto = expresion.replaceAll("\\s+", "");
        this.pos = 0;

        if (texto.isEmpty()) {
            throw new Exception("La expresion esta vacia.");
        }

        double resultado = parseExpresion();

        // Si queda algún carácter por procesar, significa que hay un error de sintaxis
        if (pos < texto.length()) {
            throw new Exception("Error de sintaxis en la expresion (caracteres inesperados al final).");
        }

        return resultado;
    }

    // Nivel 1: expresion() -> Procesa sumas y restas (+) y (-)
    private double parseExpresion() throws Exception {
        double resultado = parseTermino();
        while (pos < texto.length()) {
            char operador = texto.charAt(pos);
            if (operador == '+') {
                pos++;
                resultado += parseTermino();
            } else if (operador == '-') {
                pos++;
                resultado -= parseTermino();
            } else {
                break;
            }
        }
        return resultado;
    }

    // Nivel 2: termino() -> Procesa multiplicaciones y divisiones (*) y (/)
    private double parseTermino() throws Exception {
        double resultado = parseFactor();
        while (pos < texto.length()) {
            char operador = texto.charAt(pos);
            if (operador == '*') {
                pos++;
                resultado *= parseFactor();
            } else if (operador == '/') {
                pos++;
                double divisor = parseFactor();
                if (divisor == 0.0) {
                    throw new Exception("Error: Division por cero detectada (RF07).");
                }
                resultado /= divisor;
            } else {
                break;
            }
        }
        return resultado;
    }

    // Nivel 3: factor() -> Procesa números, signos unarios y expresiones entre paréntesis anidados
    private double parseFactor() throws Exception {
        if (pos >= texto.length()) {
            throw new Exception("Expresion incompleta o mal formada (RF06).");
        }

        char c = texto.charAt(pos);

        // Manejo de paréntesis anidados (Recursividad estructural)
        if (c == '(') {
            pos++; // Consumir '('
            double resultado = parseExpresion(); // Llamada recursiva al nivel más bajo
            if (pos >= texto.length() || texto.charAt(pos) != ')') {
                throw new Exception("Error: Parentesis sin cerrar o mal formado (RF06).");
            }
            pos++; // Consumir ')'
            return resultado;
        }

        // Manejo de números enteros o decimales
        if (Character.isDigit(c) || c == '.') {
            int inicio = pos;
            boolean tienePunto = false;
            while (pos < texto.length()) {
                char actual = texto.charAt(pos);
                if (Character.isDigit(actual)) {
                    pos++;
                } else if (actual == '.' && !tienePunto) {
                    tienePunto = true;
                    pos++;
                } else {
                    break;
                }
            }
            String numeroStr = texto.substring(inicio, pos);
            try {
                return Double.parseDouble(numeroStr);
            } catch (NumberFormatException e) {
                throw new Exception("Numero mal formado: " + numeroStr);
            }
        }

        // Manejo de signos negativos unarios (ej. -(3+2))
        if (c == '-') {
            pos++;
            return -parseFactor();
        }

        // Manejo de signos positivos unarios
        if (c == '+') {
            pos++;
            return parseFactor();
        }

        throw new Exception("Caracter inesperado '" + c + "' en la posicion " + (pos + 1));
    }
}