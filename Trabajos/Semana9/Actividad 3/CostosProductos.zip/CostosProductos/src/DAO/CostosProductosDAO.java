package DAO;

import Modelo.ComponenteModelo;
import Modelo.ProductoModelo;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class CostosProductosDAO {
    private Map<String, ProductoModelo> catalogoProductos;

    public CostosProductosDAO() {
        catalogoProductos = new HashMap<>();
    }

    // RF01, RF02, RF09: Registrar un producto base o componente
    public void registrarProducto(String codigo, String nombre, double costoUnitario) throws Exception {
        if (costoUnitario < 0) {
            throw new Exception("Error (RF09): El costo unitario no puede ser un valor negativo.");
        }
        if (catalogoProductos.containsKey(codigo)) {
            throw new Exception("Error (RF01): Ya existe un producto con el codigo " + codigo);
        }
        ProductoModelo producto = new ProductoModelo(codigo, nombre, costoUnitario);
        catalogoProductos.put(codigo, producto);
    }

    public ProductoModelo buscarProducto(String codigo) {
        return catalogoProductos.get(codigo);
    }

    // RF03, RF04, RF08, RF09: Asociar subcomponentes validando ciclos y cantidades
    public void agregarSubcomponente(String codigoPadre, String codigoHijo, int cantidad) throws Exception {
        if (cantidad <= 0) {
            throw new Exception("Error (RF09): La cantidad requerida debe ser mayor a cero.");
        }

        ProductoModelo padre = catalogoProductos.get(codigoPadre);
        ProductoModelo hijo = catalogoProductos.get(codigoHijo);

        if (padre == null || hijo == null) {
            throw new Exception("Error: El producto padre o el componente hijo no están registrados.");
        }

        // RF08: Detección de ciclos en la estructura de composición
        if (codigoPadre.equals(codigoHijo) || detectaCiclo(hijo, codigoPadre, new HashSet<>())) {
            throw new Exception("Error (RF08): Se ha detectado un ciclo o referencia circular en la estructura del producto.");
        }

        padre.agregarSubcomponente(hijo, cantidad);
    }

    // Método auxiliar recursivo para detectar ciclos
    private boolean detectaCiclo(ProductoModelo actual, String codigoBuscado, Set<String> visitados) {
        if (actual.getCodigo().equals(codigoBuscado)) {
            return true;
        }
        if (!visitados.add(actual.getCodigo())) {
            return false;
        }
        for (ComponenteModelo comp : actual.getSubcomponentes()) {
            if (detectaCiclo(comp.getSubproducto(), codigoBuscado, visitados)) {
                return true;
            }
        }
        visitados.remove(actual.getCodigo());
        return false;
    }

    // RF05: Cálculo recursivo del costo total de un producto compuesto
    public double calcularCostoTotal(ProductoModelo producto) {
        // Caso base: Si es un componente elemental (materia prima), retorna su costo unitario
        if (producto.esBase()) {
            return producto.getCostoUnitario();
        }

        // Caso recursivo: Suma el costo de cada subcomponente multiplicado por su cantidad requerida
        double costoTotal = 0.0;
        for (ComponenteModelo componente : producto.getSubcomponentes()) {
            double costoSubproducto = calcularCostoTotal(componente.getSubproducto());
            costoTotal += costoSubproducto * componente.getCantidad();
        }
        return costoTotal;
    }

    // RF06, RF10: Generar reporte detallado de costos por nivel
    public String generarReporteDesglose(ProductoModelo producto, int nivel) {
        StringBuilder sb = new StringBuilder();
        String indentacion = "  ".repeat(nivel);
        
        double costoUnitarioCalculado = calcularCostoTotal(producto);
        
        sb.append(indentacion).append("- [")
          .append(producto.getCodigo()).append("] ")
          .append(producto.getNombre())
          .append(" | Costo Total: $").append(costoUnitarioCalculado).append("\n");

        for (ComponenteModelo componente : producto.getSubcomponentes()) {
            sb.append(indentacion).append("    (Cant: ").append(componente.getCantidad()).append(")\n");
            sb.append(generarReporteDesglose(componente.getSubproducto(), nivel + 1));
        }
        
        return sb.toString();
    }

    public Map<String, ProductoModelo> getCatalogoProductos() {
        return catalogoProductos;
    }
}