package Modelo;

public class ComponenteModelo {
    private ProductoModelo subproducto;
    private int cantidad;

    public ComponenteModelo(ProductoModelo subproducto, int cantidad) {
        this.subproducto = subproducto;
        this.cantidad = cantidad;
    }

    public ProductoModelo getSubproducto() {
        return subproducto;
    }

    public void setSubproducto(ProductoModelo subproducto) {
        this.subproducto = subproducto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}