package Modelo;

import java.util.ArrayList;
import java.util.List;

public class ProductoModelo {
    private String codigo;
    private String nombre;
    private double costoUnitario; // Usado si es un componente base (materia prima)
    private List<ComponenteModelo> subcomponentes; // Lista de subproductos que lo componen

    public ProductoModelo(String codigo, String nombre, double costoUnitario) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.costoUnitario = costoUnitario;
        this.subcomponentes = new ArrayList<>();
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getCostoUnitario() {
        return costoUnitario;
    }

    public void setCostoUnitario(double costoUnitario) {
        this.costoUnitario = costoUnitario;
    }

    public List<ComponenteModelo> getSubcomponentes() {
        return subcomponentes;
    }

    public void agregarSubcomponente(ProductoModelo producto, int cantidad) {
        this.subcomponentes.add(new ComponenteModelo(producto, cantidad));
    }

    public boolean esBase() {
        return this.subcomponentes.isEmpty();
    }
}