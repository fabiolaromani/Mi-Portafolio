package Vista;

import DAO.CostosProductosDAO;
import Modelo.ProductoModelo;
import java.util.Scanner;

public class CostosProductosVista {
    private final Scanner teclado;
    private final CostosProductosDAO dao;

    public CostosProductosVista() {
        teclado = new Scanner(System.in);
        dao = new CostosProductosDAO();
    }

    public void iniciar() {
        int opcion = 0;
        do {
            System.out.println("\n--- SISTEMA DE CALCULO DE COSTOS - MANUFACTURA ---");
            System.out.println("1. Registrar producto o componente base (RF01, RF02, RF09)");
            System.out.println("2. Agregar subcomponente a producto (RF03, RF04, RF08, RF09)");
            System.out.println("3. Calcular costo total y ver reporte detallado (RF05, RF06, RF10)");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opcion: ");

            try {
                opcion = Integer.parseInt(teclado.nextLine());

                switch (opcion) {
                    case 1:
                        registrarNuevoProducto();
                        break;
                    case 2:
                        vincularSubcomponente();
                        break;
                    case 3:
                        mostrarReporteCostos();
                        break;
                    case 4:
                        System.out.println("Saliendo del sistema...");
                        break;
                    default:
                        System.out.println("Opcion invalida. Intente nuevamente.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Error: Ingrese un numero entero valido.");
            } catch (Exception e) {
                System.out.println("[ERROR] " + e.getMessage());
            }
        } while (opcion != 4);
    }

    private void registrarNuevoProducto() throws Exception {
        System.out.print("Ingrese el codigo unico del producto/componente: ");
        String codigo = teclado.nextLine();
        System.out.print("Ingrese el nombre: ");
        String nombre = teclado.nextLine();
        System.out.print("Ingrese el costo unitario (0 si es un producto compuesto a partir de subpartes): ");
        double costo = Double.parseDouble(teclado.nextLine());

        dao.registrarProducto(codigo, nombre, costo);
        System.out.println("¡Producto registrado exitosamente!");
    }

    private void vincularSubcomponente() throws Exception {
        System.out.print("Ingrese el codigo del producto PADRE (ensamblaje): ");
        String codigoPadre = teclado.nextLine();
        System.out.print("Ingrese el codigo del subcomponente HIJO: ");
        String codigoHijo = teclado.nextLine();
        System.out.print("Ingrese la cantidad requerida: ");
        int cantidad = Integer.parseInt(teclado.nextLine());

        dao.agregarSubcomponente(codigoPadre, codigoHijo, cantidad);
        System.out.println("¡Subcomponente vinculado exitosamente!");
    }

    private void mostrarReporteCostos() {
        System.out.print("Ingrese el codigo del producto final a evaluar: ");
        String codigo = teclado.nextLine();

        ProductoModelo producto = dao.buscarProducto(codigo);
        if (producto == null) {
            System.out.println("Error: El producto no se encuentra registrado.");
            return;
        }

        double costoTotal = dao.calcularCostoTotal(producto);

        System.out.println("\n--- REPORTE DE COSTOS DE FABRICACION ---");
        System.out.println("Producto: " + producto.getNombre() + " [" + producto.getCodigo() + "]");
        System.out.println("Costo Total Estimado: $" + costoTotal);
        System.out.println("\nDesglose jerarquico por niveles:");
        System.out.print(dao.generarReporteDesglose(producto, 0));
        System.out.println("----------------------------------------");
    }
}