package Modelo;

public class Nodo {
    private CitaMedica dato;
    private Nodo anterior;
    private Nodo siguiente;

    public Nodo(CitaMedica dato) {
        this.dato = dato;
        this.anterior = null;
        this.siguiente = null;
    }

    public CitaMedica getDato() { return dato; }
    public void setDato(CitaMedica dato) { this.dato = dato; }

    public Nodo getAnterior() { return anterior; }
    public void setAnterior(Nodo anterior) { this.anterior = anterior; }

    public Nodo getSiguiente() { return siguiente; }
    public void setSiguiente(Nodo siguiente) { this.siguiente = siguiente; }
}
