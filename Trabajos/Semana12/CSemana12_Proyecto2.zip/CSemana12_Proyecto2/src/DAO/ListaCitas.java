package DAO;

import Modelo.CitaMedica;
import Modelo.Nodo;

public class ListaCitas {
    private Nodo inicio;
    private Nodo fin;

    public ListaCitas() {
        this.inicio = null;
        this.fin = null;
    }

    public boolean estaVacia() {
        return inicio == null;
    }

    // 1A. Registrar cita al inicio de la lista
    public void insertarInicio(CitaMedica cita) {
        Nodo nuevo = new Nodo(cita);
        if (estaVacia()) {
            inicio = fin = nuevo;
        } else {
            nuevo.setSiguiente(inicio);
            inicio.setAnterior(nuevo);
            inicio = nuevo;
        }
    }

    // 1B. Registrar cita al final de la lista
    public void insertarFinal(CitaMedica cita) {
        Nodo nuevo = new Nodo(cita);
        if (estaVacia()) {
            inicio = fin = nuevo;
        } else {
            fin.setSiguiente(nuevo);
            nuevo.setAnterior(fin);
            fin = nuevo;
        }
    }

    // 2. Insertar cita en una posición determinada (1-based index)
    public boolean insertarEnPosicion(CitaMedica cita, int posicion) {
        if (posicion < 1) {
            return false;
        }
        if (posicion == 1) {
            insertarInicio(cita);
            return true;
        }

        Nodo actual = inicio;
        int contador = 1;

        while (actual != null && contador < posicion - 1) {
            actual = actual.getSiguiente();
            contador++;
        }

        if (actual == null) {
            return false; // Posición fuera de rango
        }

        if (actual == fin) {
            insertarFinal(cita);
        } else {
            Nodo nuevo = new Nodo(cita);
            Nodo siguienteNodo = actual.getSiguiente();

            nuevo.setSiguiente(siguienteNodo);
            nuevo.setAnterior(actual);
            actual.setSiguiente(nuevo);
            siguienteNodo.setAnterior(nuevo);
        }
        return true;
    }

    // 3. Buscar una cita mediante su código o DNI del paciente
    public Nodo buscarPorCodigoODni(String criterio) {
        Nodo actual = inicio;
        while (actual != null) {
            CitaMedica c = actual.getDato();
            if (c.getCodigoCita().equalsIgnoreCase(criterio) || 
                c.getDniPaciente().equalsIgnoreCase(criterio)) {
                return actual;
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    // 4. Modificar la información de una cita médica (buscando por código)
    public boolean modificarCita(String codigo, String nuevoDni, String nuevosNombres, 
                                 String nuevaEspecialidad, String nuevoMedico, 
                                 String nuevaFecha, String nuevaHora, String nuevoEstado) {
        Nodo encontrado = buscarPorCodigoODni(codigo);
        if (encontrado != null && encontrado.getDato().getCodigoCita().equalsIgnoreCase(codigo)) {
            CitaMedica c = encontrado.getDato();
            c.setDniPaciente(nuevoDni);
            c.setNombresApellidos(nuevosNombres);
            c.setEspecialidad(nuevaEspecialidad);
            c.setNombreMedico(nuevoMedico);
            c.setFechaAtencion(nuevaFecha);
            c.setHoraAtencion(nuevaHora);
            c.setEstadoCita(nuevoEstado);
            return true;
        }
        return false;
    }

    // 5A. Cancelar cita (cambia estado a "Cancelada")
    public boolean cancelarCita(String codigo) {
        Nodo encontrado = buscarPorCodigoODni(codigo);
        if (encontrado != null && encontrado.getDato().getCodigoCita().equalsIgnoreCase(codigo)) {
            encontrado.getDato().setEstadoCita("Cancelada");
            return true;
        }
        return false;
    }

    // 5B. Eliminar físicamente el nodo de la lista
    public boolean eliminarCita(String codigo) {
        Nodo actual = inicio;
        while (actual != null) {
            if (actual.getDato().getCodigoCita().equalsIgnoreCase(codigo)) {
                if (actual == inicio && actual == fin) {
                    inicio = fin = null;
                } else if (actual == inicio) {
                    inicio = inicio.getSiguiente();
                    inicio.setAnterior(null);
                } else if (actual == fin) {
                    fin = fin.getAnterior();
                    fin.setSiguiente(null);
                } else {
                    actual.getAnterior().setSiguiente(actual.getSiguiente());
                    actual.getSiguiente().setAnterior(actual.getAnterior());
                }
                return true;
            }
            actual = actual.getSiguiente();
        }
        return false;
    }

    // 6. Mostrar todas las citas desde la primera hasta la última
    public String mostrarAdelante() {
        if (estaVacia()) {
            return "No hay citas médicas registradas.";
        }
        StringBuilder sb = new StringBuilder("=== LISTA DE CITAS (INICIO -> FIN) ===\n");
        Nodo actual = inicio;
        while (actual != null) {
            sb.append(actual.getDato().toString()).append("\n");
            actual = actual.getSiguiente();
        }
        return sb.toString();
    }

    // 7. Mostrar todas las citas en orden inverso
    public String mostrarAtras() {
        if (estaVacia()) {
            return "No hay citas médicas registradas.";
        }
        StringBuilder sb = new StringBuilder("=== LISTA DE CITAS (FIN -> INICIO) ===\n");
        Nodo actual = fin;
        while (actual != null) {
            sb.append(actual.getDato().toString()).append("\n");
            actual = actual.getAnterior();
        }
        return sb.toString();
    }

    // 8. Ordenar las citas por fecha y hora de atención (Método Burbuja intercambiando datos)
    public void ordenarPorFechaYHora() {
        if (estaVacia() || inicio == fin) {
            return;
        }
        boolean huboCambio;
        do {
            huboCambio = false;
            Nodo actual = inicio;
            while (actual.getSiguiente() != null) {
                CitaMedica c1 = actual.getDato();
                CitaMedica c2 = actual.getSiguiente().getDato();

                // Concatenamos fecha y hora para comparar cronológicamente
                String fechaHora1 = c1.getFechaAtencion() + " " + c1.getHoraAtencion();
                String fechaHora2 = c2.getFechaAtencion() + " " + c2.getHoraAtencion();

                if (fechaHora1.compareTo(fechaHora2) > 0) {
                    actual.setDato(c2);
                    actual.getSiguiente().setDato(c1);
                    huboCambio = true;
                }
                actual = actual.getSiguiente();
            }
        } while (huboCambio);
    }

    // 9. Buscar las citas correspondientes a un médico determinado
    public String buscarPorMedico(String nombreMedico) {
        if (estaVacia()) {
            return "No hay citas registradas.";
        }
        StringBuilder sb = new StringBuilder("=== CITAS DEL MÉDICO: " + nombreMedico + " ===\n");
        Nodo actual = inicio;
        boolean encontrado = false;
        while (actual != null) {
            if (actual.getDato().getNombreMedico().equalsIgnoreCase(nombreMedico)) {
                sb.append(actual.getDato().toString()).append("\n");
                encontrado = true;
            }
            actual = actual.getSiguiente();
        }
        return encontrado ? sb.toString() : "No se encontraron citas para el médico indicado.";
    }

    // 10. Contabilizar las citas registradas, atendidas y canceladas
    public String contabilizarCitas() {
        int total = 0;
        int registradas = 0;
        int atendidas = 0;
        int canceladas = 0;

        Nodo actual = inicio;
        while (actual != null) {
            total++;
            String estado = actual.getDato().getEstadoCita();
            if (estado.equalsIgnoreCase("Registrada")) {
                registradas++;
            } else if (estado.equalsIgnoreCase("Atendida")) {
                atendidas++;
            } else if (estado.equalsIgnoreCase("Cancelada")) {
                canceladas++;
            }
            actual = actual.getSiguiente();
        }

        return "=== RESUMEN DE CITAS MÉDICAS ===\n" +
               "Total de citas en sistema : " + total + "\n" +
               "- Registradas (Pendientes): " + registradas + "\n" +
               "- Atendidas               : " + atendidas + "\n" +
               "- Canceladas              : " + canceladas;
    }
}