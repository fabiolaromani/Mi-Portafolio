package Vista;

import DAO.ListaCitas;
import Modelo.CitaMedica;
import Modelo.Nodo;
import java.util.Scanner;

public class MenuOpciones {
    private ListaCitas lista;
    private Scanner sc;

    public MenuOpciones() {
        lista = new ListaCitas();
        sc = new Scanner(System.in);
    }

    public void iniciar() {
        int opcion = 0;
        do {
            System.out.println("\n==============================================");
            System.out.println("  SISTEMA DE GESTIÓN DE CITAS MÉDICAS");
            System.out.println("==============================================");
            System.out.println("1. Registrar cita al inicio");
            System.out.println("2. Registrar cita al final");
            System.out.println("3. Insertar cita en una posición determinada");
            System.out.println("4. Buscar cita por código o DNI");
            System.out.println("5. Modificar información de una cita");
            System.out.println("6. Cancelar o eliminar una cita");
            System.out.println("7. Mostrar citas (Primera a Última)");
            System.out.println("8. Mostrar citas en orden inverso (Última a Primera)");
            System.out.println("9. Ordenar citas por fecha y hora de atención");
            System.out.println("10. Buscar citas por médico");
            System.out.println("11. Contabilizar citas (Registradas, Atendidas, Canceladas)");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                opcion = -1;
            }

            switch (opcion) {
                case 1:
                    lista.insertarInicio(leerDatosCita());
                    System.out.println("Cita registrada al inicio correctamente.");
                    break;
                case 2:
                    lista.insertarFinal(leerDatosCita());
                    System.out.println("Cita registrada al final correctamente.");
                    break;
                case 3:
                    System.out.print("Ingrese la posición donde desea insertar (1 en adelante): ");
                    int pos = Integer.parseInt(sc.nextLine());
                    CitaMedica nuevaCita = leerDatosCita();
                    if (lista.insertarEnPosicion(nuevaCita, pos)) {
                        System.out.println("Cita insertada en la posición " + pos + ".");
                    } else {
                        System.out.println("Posición inválida o fuera de rango.");
                    }
                    break;
                case 4:
                    System.out.print("Ingrese código de cita o DNI del paciente: ");
                    String criterio = sc.nextLine();
                    Nodo encontrado = lista.buscarPorCodigoODni(criterio);
                    if (encontrado != null) {
                        System.out.println("Cita encontrada:\n" + encontrado.getDato());
                    } else {
                        System.out.println("No se encontró ninguna cita con ese dato.");
                    }
                    break;
                case 5:
                    opcionModificar();
                    break;
                case 6:
                    opcionCancelarOEliminar();
                    break;
                case 7:
                    System.out.println(lista.mostrarAdelante());
                    break;
                case 8:
                    System.out.println(lista.mostrarAtras());
                    break;
                case 9:
                    lista.ordenarPorFechaYHora();
                    System.out.println("Citas ordenadas cronológicamente por fecha y hora.");
                    System.out.println(lista.mostrarAdelante());
                    break;
                case 10:
                    System.out.print("Ingrese el nombre del médico: ");
                    String medico = sc.nextLine();
                    System.out.println(lista.buscarPorMedico(medico));
                    break;
                case 11:
                    System.out.println(lista.contabilizarCitas());
                    break;
                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        } while (opcion != 0);
    }

    private CitaMedica leerDatosCita() {
        System.out.print("Código de cita: ");
        String codigo = sc.nextLine();
        System.out.print("DNI del paciente: ");
        String dni = sc.nextLine();
        System.out.print("Nombres y apellidos del paciente: ");
        String nombres = sc.nextLine();
        System.out.print("Especialidad médica: ");
        String especialidad = sc.nextLine();
        System.out.print("Nombre del médico: ");
        String medico = sc.nextLine();
        System.out.print("Fecha de atención (YYYY-MM-DD): ");
        String fecha = sc.nextLine();
        System.out.print("Hora de atención (HH:MM): ");
        String hora = sc.nextLine();
        System.out.print("Estado de la cita (Registrada / Atendida / Cancelada): ");
        String estado = sc.nextLine();

        return new CitaMedica(codigo, dni, nombres, especialidad, medico, fecha, hora, estado);
    }

    private void opcionModificar() {
        System.out.print("Ingrese el código de la cita a modificar: ");
        String codigo = sc.nextLine();
        Nodo nodo = lista.buscarPorCodigoODni(codigo);

        if (nodo != null && nodo.getDato().getCodigoCita().equalsIgnoreCase(codigo)) {
            System.out.println("Datos actuales:\n" + nodo.getDato());
            System.out.println("--- Ingrese los nuevos datos ---");
            System.out.print("Nuevo DNI del paciente: ");
            String dni = sc.nextLine();
            System.out.print("Nuevos nombres y apellidos: ");
            String nombres = sc.nextLine();
            System.out.print("Nueva especialidad médica: ");
            String especialidad = sc.nextLine();
            System.out.print("Nuevo nombre del médico: ");
            String medico = sc.nextLine();
            System.out.print("Nueva fecha de atención (YYYY-MM-DD): ");
            String fecha = sc.nextLine();
            System.out.print("Nueva hora de atención (HH:MM): ");
            String hora = sc.nextLine();
            System.out.print("Nuevo estado (Registrada / Atendida / Cancelada): ");
            String estado = sc.nextLine();

            if (lista.modificarCita(codigo, dni, nombres, especialidad, medico, fecha, hora, estado)) {
                System.out.println("Cita modificada exitosamente.");
            }
        } else {
            System.out.println("No existe una cita con el código ingresado.");
        }
    }

    private void opcionCancelarOEliminar() {
        System.out.println("1. Cancelar cita (Cambiar estado a 'Cancelada')");
        System.out.println("2. Eliminar cita definitivamente de la lista");
        System.out.print("Elija acción: ");
        String subOpcion = sc.nextLine();

        System.out.print("Ingrese el código de la cita: ");
        String codigo = sc.nextLine();

        if (subOpcion.equals("1")) {
            if (lista.cancelarCita(codigo)) {
                System.out.println("La cita ha sido marcada como Cancelada.");
            } else {
                System.out.println("No se encontró la cita.");
            }
        } else if (subOpcion.equals("2")) {
            if (lista.eliminarCita(codigo)) {
                System.out.println("La cita fue eliminada de la lista.");
            } else {
                System.out.println("No se encontró la cita.");
            }
        } else {
            System.out.println("Acción no válida.");
        }
    }
}