package Modelo;

public class Nodo {

    // Información del alumno
    public Alumno dato;

    // Referencia al nodo anterior
    public Nodo anterior;

    // Referencia al nodo siguiente
    public Nodo siguiente;

    // Constructor
    public Nodo(Alumno dato) {

        this.dato = dato;
        this.anterior = null;
        this.siguiente = null;
    }
}
