package vista;

import DAO.ClistaDoble;

public class Principal {

    public static void main(String[] args) {

        // Crear la estructura de datos
        ClistaDoble lista = new ClistaDoble();

        // Crear el menú
       MenuOpciones menu = new MenuOpciones(lista);

        // Ejecutar la aplicación
        menu.mostrarMenu();
    }
}

