package modelo;

public class ArchivoInfo {
    private String nombre;
    private String rutaAbsoluta;
    private long tamanoBytes;
    private String extension;
    private boolean esDirectorio;

    public ArchivoInfo(String nombre, String rutaAbsoluta, long tamanoBytes, String extension, boolean esDirectorio) {
        this.nombre = nombre;
        this.rutaAbsoluta = rutaAbsoluta;
        this.tamanoBytes = tamanoBytes;
        this.extension = extension;
        this.esDirectorio = esDirectorio;
    }

    // Getters y Setters (Encapsulamiento estricto)
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getRutaAbsoluta() { return rutaAbsoluta; }
    public void setRutaAbsoluta(String rutaAbsoluta) { this.rutaAbsoluta = rutaAbsoluta; }

    public long getTamanoBytes() { return tamanoBytes; }
    public void setTamanoBytes(long tamanoBytes) { this.tamanoBytes = tamanoBytes; }

    public String getExtension() { return extension; }
    public void setExtension(String extension) { this.extension = extension; }

    public boolean isEsDirectorio() { return esDirectorio; }
    public void setEsDirectorio(boolean esDirectorio) { this.esDirectorio = esDirectorio; }

    @Override
    public String toString() {
        String tipo = esDirectorio ? "[Carpeta]" : "[Archivo]";
        return tipo + " " + nombre + " (" + tamanoBytes + " bytes)";
    }
}
