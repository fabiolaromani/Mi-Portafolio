package vista;

import dao.FileAnalyzerDao;
import modelo.ArchivoInfo;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FileAnalyzerDao dao = new FileAnalyzerDao();
        List<ArchivoInfo> inventarioArchivos = new ArrayList<>();

        System.out.println("=== SISTEMA DE GESTIÓN Y ANÁLISIS DE ARCHIVOS ===");
        System.out.print("Ingrese la ruta absoluta del directorio raíz a analizar: ");
        String rutaRaiz = scanner.nextLine();

        try {
            File raiz = new File(rutaRaiz);
            System.out.println("\nAnalizando directorios de forma recursiva...");
            dao.analizarDirectorioRecursivo(raiz, inventarioArchivos);

            // 3. Contabilizar archivos y carpetas
            long totalArchivos = inventarioArchivos.stream().filter(a -> !a.isEsDirectorio()).count();
            long totalCarpetas = inventarioArchivos.stream().filter(ArchivoInfo::isEsDirectorio).count();
            long tamanoTotal = dao.calcularTamanoTotal(inventarioArchivos);

            System.out.println("\n--- REPORTE GENERAL ---");
            System.out.println("Carpetas encontradas: " + totalCarpetas);
            System.out.println("Archivos encontrados: " + totalArchivos);
            System.out.println("Tamaño total: " + (tamanoTotal / 1024.0) + " KB");

            // 6. Reporte por tipo
            System.out.println("\n--- CANTIDAD DE ARCHIVOS POR TIPO ---");
            Map<String, Integer> reporteTipos = dao.generarReportePorTipo(inventarioArchivos);
            for (Map.Entry<String, Integer> entry : reporteTipos.entrySet()) {
                System.out.println("Extensión ." + entry.getKey() + ": " + entry.getValue() + " archivo(s)");
            }

            // 5. Búsqueda de ejemplo
            System.out.print("\nIngrese una extensión o nombre para buscar (ej. pdf, docx): ");
            String busqueda = scanner.nextLine();
            List<ArchivoInfo> resultados = dao.buscarArchivos(inventarioArchivos, busqueda);
            
            System.out.println("Resultados de búsqueda (" + resultados.size() + "):");
            for (ArchivoInfo res : resultados) {
                System.out.println(" - " + res.getRutaAbsoluta());
            }

        } catch (Exception e) {
            System.err.println("Error durante la ejecución: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
