package dao;

import modelo.ArchivoInfo;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FileAnalyzerDao {

    // 1 y 2. Recorrido recursivo y listado de archivos/carpetas
    public void analizarDirectorioRecursivo(File directorio, List<ArchivoInfo> listaAcumulada) {
        if (directorio == null || !directorio.exists()) {
            throw new IllegalArgumentException("El directorio especificado no existe o es inválido.");
        }

        File[] archivos = directorio.listFiles();
        if (archivos != null) {
            for (File archivo : archivos) {
                String nombre = archivo.getName();
                String ruta = archivo.getAbsolutePath();
                long tamano = archivo.isDirectory() ? 0 : archivo.length();
                boolean esDir = archivo.isDirectory();
                
                String ext = "";
                if (!esDir) {
                    int lastIndex = nombre.lastIndexOf('.');
                    if (lastIndex > 0 && lastIndex < nombre.length() - 1) {
                        ext = nombre.substring(lastIndex + 1).toLowerCase();
                    } else {
                        ext = "sin_extension";
                    }
                } else {
                    ext = "directorio";
                }

                ArchivoInfo info = new ArchivoInfo(nombre, ruta, tamano, ext, esDir);
                listaAcumulada.add(info);

                // Llamada recursiva si es un subdirectorio
                if (esDir) {
                    analizarDirectorioRecursivo(archivo, listaAcumulada);
                }
            }
        }
    }

    // 4. Calcular el tamaño total de los archivos accesibles
    public long calcularTamanoTotal(List<ArchivoInfo> archivos) {
        long total = 0;
        for (ArchivoInfo a : archivos) {
            if (!a.isEsDirectorio()) {
                total += a.getTamanoBytes();
            }
        }
        return total;
    }

    // 5. Buscar archivos por nombre o extensión
    public List<ArchivoInfo> buscarArchivos(List<ArchivoInfo> archivos, String criterio) {
        List<ArchivoInfo> resultados = new ArrayList<>();
        String criterioLower = criterio.toLowerCase();
        for (ArchivoInfo a : archivos) {
            if (a.getNombre().toLowerCase().contains(criterioLower) || 
                a.getExtension().toLowerCase().equals(criterioLower)) {
                resultados.add(a);
            }
        }
        return resultados;
    }

    // 6. Generar reporte con la cantidad de archivos por tipo (extensión)
    public Map<String, Integer> generarReportePorTipo(List<ArchivoInfo> archivos) {
        Map<String, Integer> reporte = new HashMap<>();
        for (ArchivoInfo a : archivos) {
            if (!a.isEsDirectorio()) {
                String tipo = a.getExtension();
                reporte.put(tipo, reporte.getOrDefault(tipo, 0) + 1);
            }
        }
        return reporte;
    }
}