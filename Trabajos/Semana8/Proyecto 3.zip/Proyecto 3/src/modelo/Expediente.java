package modelo;

public class Expediente implements Comparable<Expediente> {
    private String codigo;
    private String nombreEstudiante;
    private String estado; // Ej. "Matriculado", "Egresado", "Observado"

    public Expediente(String codigo, String nombreEstudiante, String estado) {
        this.codigo = codigo;
        this.nombreEstudiante = nombreEstudiante;
        this.estado = estado;
    }

    // Getters y Setters (Encapsulamiento estricto)
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getNombreEstudiante() { return nombreEstudiante; }
    public void setNombreEstudiante(String nombreEstudiante) { this.nombreEstudiante = nombreEstudiante; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    @Override
    public int compareTo(Expediente otro) {
        return this.codigo.compareToIgnoreCase(otro.codigo);
    }

    @Override
    public String toString() {
        return "Código: " + codigo + " | Estudiante: " + nombreEstudiante + " | Estado: " + estado;
    }
}