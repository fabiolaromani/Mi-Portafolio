package modelo;

public class NodoArbol {
    private Expediente expediente;
    private NodoArbol izquierdo;
    private NodoArbol derecho;

    public NodoArbol(Expediente expediente) {
        this.expediente = expediente;
        this.izquierdo = null;
        this.derecho = null;
    }

    public Expediente getExpediente() { return expediente; }
    public void setExpediente(Expediente expediente) { this.expediente = expediente; }

    public NodoArbol getIzquierdo() { return izquierdo; }
    public void setIzquierdo(NodoArbol izquierdo) { this.izquierdo = izquierdo; }

    public NodoArbol getDerecho() { return derecho; }
    public void setDerecho(NodoArbol derecho) { this.derecho = derecho; }
}