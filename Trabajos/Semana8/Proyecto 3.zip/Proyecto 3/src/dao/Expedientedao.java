package dao;

import modelo.Expediente;
import modelo.NodoArbol;
import java.util.ArrayList;
import java.util.List;

public class Expedientedao {
    private NodoArbol raiz;

    public Expedientedao() {
        this.raiz = null;
    }

    // 2. Insertar expedientes en un Árbol Binario de Búsqueda de forma recursiva
    public void insertar(Expediente expediente) {
        raiz = insertarRecursivo(raiz, expediente);
    }

    private NodoArbol insertarRecursivo(NodoArbol actual, Expediente expediente) {
        if (actual == null) {
            return new NodoArbol(expediente);
        }

        int comparacion = expediente.compareTo(actual.getExpediente());
        if (comparacion < 0) {
            actual.setIzquierdo(insertarRecursivo(actual.getIzquierdo(), expediente));
        } else if (comparacion > 0) {
            actual.setDerecho(insertarRecursivo(actual.getDerecho(), expediente));
        } else {
            throw new IllegalArgumentException("Ya existe un expediente con el código: " + expediente.getCodigo());
        }
        return actual;
    }

    // 3. Buscar expedientes mediante su código (Recursivo)
    public Expediente buscar(String codigo) {
        return buscarRecursivo(raiz, codigo);
    }

    private Expediente buscarRecursivo(NodoArbol actual, String codigo) {
        if (actual == null) {
            return null;
        }
        int comparacion = codigo.compareToIgnoreCase(actual.getExpediente().getCodigo());
        if (comparacion == 0) {
            return actual.getExpediente();
        }
        return comparacion < 0 ? buscarRecursivo(actual.getIzquierdo(), codigo) 
                               : buscarRecursivo(actual.getDerecho(), codigo);
    }

    // 4. Mostrar los expedientes en orden ascendente (Recorrido In-Order)
    public List<Expediente> obtenerOrdenAscendente() {
        List<Expediente> lista = new ArrayList<>();
        inOrderRecursivo(raiz, lista);
        return lista;
    }

    private void inOrderRecursivo(NodoArbol actual, List<Expediente> lista) {
        if (actual != null) {
            inOrderRecursivo(actual.getIzquierdo(), lista);
            lista.add(actual.getExpediente());
            inOrderRecursivo(actual.getDerecho(), lista);
        }
    }

    // 5. Calcular la cantidad total de expedientes (Conteo recursivo)
    public int contarExpedientes() {
        return contarRecursivo(raiz);
    }

    private int contarRecursivo(NodoArbol actual) {
        if (actual == null) {
            return 0;
        }
        return 1 + contarRecursivo(actual.getIzquierdo()) + contarRecursivo(actual.getDerecho());
    }

    // 6. Determinar la altura del árbol
    public int obtenerAltura() {
        return alturaRecursiva(raiz);
    }

    private int alturaRecursiva(NodoArbol actual) {
        if (actual == null) {
            return -1; // O 0 dependiendo de la convención (altura de árbol vacío = -1)
        }
        int alturaIzq = alturaRecursiva(actual.getIzquierdo());
        int alturaDer = alturaRecursiva(actual.getDerecho());
        return Math.max(alturaIzq, alturaDer) + 1;
    }

    // 7. Identificar expedientes que cumplen un criterio (ej. filtrar por estado)
    public List<Expediente> buscarPorEstado(String estado) {
        List<Expediente> resultado = new ArrayList<>();
        filtrarEstadoRecursivo(raiz, estado, resultado);
        return resultado;
    }

    private void filtrarEstadoRecursivo(NodoArbol actual, String estado, List<Expediente> resultado) {
        if (actual != null) {
            filtrarEstadoRecursivo(actual.getIzquierdo(), estado, resultado);
            if (actual.getExpediente().getEstado().equalsIgnoreCase(estado)) {
                resultado.add(actual.getExpediente());
            }
            filtrarEstadoRecursivo(actual.getDerecho(), estado, resultado);
        }
    }
}