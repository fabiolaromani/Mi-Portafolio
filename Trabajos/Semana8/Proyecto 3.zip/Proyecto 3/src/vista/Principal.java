package vista;

import dao.Expedientedao;
import modelo.Expediente;

import java.util.List;
import java.util.Scanner;

public class Principal{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Expedientedao dao = new Expedientedao();

        // Datos de prueba iniciales
        try {
            dao.insertar(new Expediente("EXP-2026-05", "Lucía Mendoza", "Matriculado"));
            dao.insertar(new Expediente("EXP-2026-02", "Carlos Pérez", "Egresado"));
            dao.insertar(new Expediente("EXP-2026-08", "Ana Torres", "Matriculado"));
            dao.insertar(new Expediente("EXP-2026-01", "David Gómez", "Observado"));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        int opcion = 0;
        do {
            System.out.println("\n=== SISTEMA DE GESTIÓN DE EXPEDIENTES ACADÉMICOS (ABB) ===");
            System.out.println("1. Registrar expediente");
            System.out.println("2. Buscar expediente por código");
            System.out.println("3. Mostrar expedientes en orden ascendente (In-Order)");
            System.out.println("4. Mostrar cantidad total de expedientes");
            System.out.println("5. Mostrar altura del árbol");
            System.out.println("6. Filtrar expedientes por estado (ej. Matriculado)");
            System.out.println("7. Salir");
            System.out.print("Seleccione una opción: ");

            if (scanner.hasNextInt()) {
                opcion = scanner.nextInt();
                scanner.nextLine();
            } else {
                scanner.next();
                continue;
            }

            switch (opcion) {
                case 1:
                    System.out.print("Código del expediente: ");
                    String cod = scanner.nextLine();
                    System.out.print("Nombre del estudiante: ");
                    String nom = scanner.nextLine();
                    System.out.print("Estado (Matriculado/Egresado/Observado): ");
                    String est = scanner.nextLine();
                    try {
                        dao.insertar(new Expediente(cod, nom, est));
                        System.out.println("¡Expediente insertado con éxito en el ABB!");
                    } catch (Exception ex) {
                        System.err.println("Error: " + ex.getMessage());
                    }
                    break;
                case 2:
                    System.out.print("Ingrese el código a buscar: ");
                    String codigoBuscado = scanner.nextLine();
                    Expediente exp = dao.buscar(codigoBuscado);
                    if (exp != null) {
                        System.out.println("¡Encontrado!: " + exp);
                    } else {
                        System.out.println("Expediente no encontrado.");
                    }
                    break;
                case 3:
                    System.out.println("\n--- EXPEDIENTES ORDENADOS (ASCENDENTE) ---");
                    List<Expediente> ordenados = dao.obtenerOrdenAscendente();
                    for (Expediente e : ordenados) {
                        System.out.println(e);
                    }
                    break;
                case 4:
                    int total = dao.contarExpedientes();
                    System.out.println("Cantidad total de expedientes: " + total);
                    break;
                case 5:
                    int altura = dao.obtenerAltura();
                    System.out.println("Altura del árbol binario: " + altura);
                    break;
                case 6:
                    System.out.print("Ingrese el estado a filtrar: ");
                    String estadoFiltro = scanner.nextLine();
                    List<Expediente> filtrados = dao.buscarPorEstado(estadoFiltro);
                    System.out.println("\n--- RESULTADOS PARA ESTADO: " + estadoFiltro + " ---");
                    for (Expediente e : filtrados) {
                        System.out.println(e);
                    }
                    break;
                case 7:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 7);

        scanner.close();
    }
}