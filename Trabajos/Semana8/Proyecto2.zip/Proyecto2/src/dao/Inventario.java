package dao;

import modelo.Producto;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Inventario {
    private List<Producto> listaProductos = new ArrayList<>();

    public void registrarProducto(Producto producto) {
        // Validar que no exista el código
        for (Producto p : listaProductos) {
            if (p.getCodigo().equalsIgnoreCase(producto.getCodigo())) {
                throw new IllegalArgumentException("Ya existe un producto con el código: " + producto.getCodigo());
            }
        }
        listaProductos.add(producto);
        Collections.sort(listaProductos); // Mantener ordenado para búsqueda binaria
    }

    public List<Producto> obtenerProductos() {
        return listaProductos;
    }

    // 3. Búsqueda binaria recursiva por código
    public Producto buscarBinarioRecursivo(List<Producto> lista, String codigoBuscado, int inicio, int fin) {
        if (inicio > fin) {
            return null; // No encontrado
        }

        int medio = inicio + (fin - inicio) / 2;
        Producto actual = lista.get(medio);
        int comparacion = actual.getCodigo().compareToIgnoreCase(codigoBuscado);

        if (comparacion == 0) {
            return actual;
        } else if (comparacion > 0) {
            return buscarBinarioRecursivo(lista, codigoBuscado, inicio, medio - 1);
        } else {
            return buscarBinarioRecursivo(lista, codigoBuscado, medio + 1, fin);
        }
    }

    // Método envoltorio para la búsqueda binaria
    public Producto buscarProducto(String codigo) {
        return buscarBinarioRecursivo(listaProductos, codigo, 0, listaProductos.size() - 1);
    }

    // 4. Calcular recursivamente el valor total del inventario
    public double calcularValorInventarioRecursivo(int indice) {
        if (indice < 0 || indice >= listaProductos.size()) {
            return 0.0;
        }
        Producto p = listaProductos.get(indice);
        double valorActual = p.getPrecio() * p.getCantidadDisponible();
        return valorActual + calcularValorInventarioRecursivo(indice + 1);
    }

    // 5. Determinar la cantidad total de unidades disponibles
    public int calcularTotalUnidades() {
        int total = 0;
        for (Producto p : listaProductos) {
            total += p.getCantidadDisponible();
        }
        return total;
    }

    // 6. Identificar productos sin existencias (Stock = 0)
    public List<Producto> obtenerProductosSinExistencias() {
        List<Producto> sinStock = new ArrayList<>();
        for (Producto p : listaProductos) {
            if (p.getCantidadDisponible() == 0) {
                sinStock.add(p);
            }
        }
        return sinStock;
    }

    // 7. Generar reporte de productos con bajo inventario (ej. stock < 5)
    public List<Producto> obtenerProductosBajoInventario(int umbral) {
        List<Producto> bajoStock = new ArrayList<>();
        for (Producto p : listaProductos) {
            if (p.getCantidadDisponible() > 0 && p.getCantidadDisponible() < umbral) {
                bajoStock.add(p);
            }
        }
        return bajoStock;
    }
}