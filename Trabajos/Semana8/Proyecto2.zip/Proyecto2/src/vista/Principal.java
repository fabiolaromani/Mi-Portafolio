package vista;

import dao.Inventario;
import modelo.Producto;

import java.util.List;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Inventario dao = new Inventario();

        // Datos de prueba iniciales
        try {
            dao.registrarProducto(new Producto("P001", "Laptop Core i5", 2500.00, 4));
            dao.registrarProducto(new Producto("P002", "Mouse Inalámbrico", 45.50, 0));
            dao.registrarProducto(new Producto("P003", "Teclado Mecánico", 180.00, 12));
            dao.registrarProducto(new Producto("P004", "Monitor 24 pulgadas", 750.00, 2));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        int opcion = 0;
        do {
            System.out.println("\n=== SISTEMA DE GESTIÓN DE INVENTARIO ===");
            System.out.println("1. Registrar producto");
            System.out.println("2. Mostrar todos los productos");
            System.out.println("3. Buscar producto por código (Binaria Recursiva)");
            System.out.println("4. Calcular valor total del inventario (Recursivo)");
            System.out.println("5. Mostrar productos sin existencias");
            System.out.println("6. Mostrar reporte de bajo inventario (Stock < 5)");
            System.out.println("7. Salir");
            System.out.print("Seleccione una opción: ");
            
            if (scanner.hasNextInt()) {
                opcion = scanner.nextInt();
                scanner.nextLine(); // limpiar buffer
            } else {
                scanner.next();
                continue;
            }

            switch (opcion) {
                case 1:
                    System.out.print("Código: ");
                    String cod = scanner.nextLine();
                    System.out.print("Descripción: ");
                    String desc = scanner.nextLine();
                    System.out.print("Precio: ");
                    double precio = scanner.nextDouble();
                    System.out.print("Cantidad disponible: ");
                    int stock = scanner.nextInt();
                    scanner.nextLine();
                    try {
                        dao.registrarProducto(new Producto(cod, desc, precio, stock));
                        System.out.println("¡Producto registrado con éxito!");
                    } catch (Exception ex) {
                        System.err.println("Error: " + ex.getMessage());
                    }
                    break;
                case 2:
                    System.out.println("\n--- LISTA DE PRODUCTOS ---");
                    for (Producto p : dao.obtenerProductos()) {
                        System.out.println(p);
                    }
                    break;
                case 3:
                    System.out.print("Ingrese el código a buscar: ");
                    String codigoBusqueda = scanner.nextLine();
                    Producto encontrado = dao.buscarProducto(codigoBusqueda);
                    if (encontrado != null) {
                        System.out.println("¡Encontrado!: " + encontrado);
                    } else {
                        System.out.println("Producto no encontrado.");
                    }
                    break;
                case 4:
                    double valorTotal = dao.calcularValorInventarioRecursivo(0);
                    System.out.println("Valor total del inventario: S/ " + valorTotal);
                    break;
                case 5:
                    List<Producto> sinStockList = dao.obtenerProductosSinExistencias();
                    System.out.println("\n--- PRODUCTOS SIN STOCK ---");
                    for (Producto p : sinStockList) {
                        System.out.println(p);
                    }
                    break;
                case 6:
                    List<Producto> bajoStockList = dao.obtenerProductosBajoInventario(5);
                    System.out.println("\n--- PRODUCTOS CON BAJO INVENTARIO (< 5) ---");
                    for (Producto p : bajoStockList) {
                        System.out.println(p);
                    }
                    break;
                case 7:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 7);

        scanner.close();
    }
}