package modelo;

public class Producto implements Comparable<Producto> {
    private String codigo;
    private String descripcion;
    private double precio;
    private int cantidadDisponible;

    public Producto(String codigo, String descripcion, double precio, int cantidadDisponible) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.precio = precio;
        this.cantidadDisponible = cantidadDisponible;
    }

    // Getters y Setters (Encapsulamiento estricto)
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }

    public int getCantidadDisponible() { return cantidadDisponible; }
    public void setCantidadDisponible(int cantidadDisponible) { this.cantidadDisponible = cantidadDisponible; }

    @Override
    public int compareTo(Producto otro) {
        return this.codigo.compareTo(otro.codigo);
    }

    @Override
    public String toString() {
        return "Código: " + codigo + " | Descripción: " + descripcion + 
               " | Precio: S/ " + precio + " | Stock: " + cantidadDisponible;
    }
}