package Vista;

import DAO.CListaCircular;
import Modelo.Alumno;
import java.util.ArrayList;

public class Principal {

    public static void main(String[] args) {

        // Instanciar la lista circular
        CListaCircular lista = new CListaCircular();

        // Instanciar la vista
        MenuOpciones menu = new MenuOpciones();

        int opcion;

        do {

            menu.mostrarMenu();

            opcion = menu.leerEntero("Seleccione una opcion: ");

            switch (opcion) {

                // 1. INSERTAR AL INICIO
                case 1: {

                    Alumno alumno = menu.leerAlumno();

                    if (lista.insertarInicio(alumno)) {
                        menu.mostrarMensaje(
                                "Alumno insertado al inicio correctamente.");
                    } else {
                        menu.mostrarMensaje(
                                "No se pudo insertar. Codigo duplicado.");
                    }

                    break;
                }

                // 2. INSERTAR AL FINAL
                case 2: {

                    Alumno alumno = menu.leerAlumno();

                    if (lista.insertarFinal(alumno)) {
                        menu.mostrarMensaje(
                                "Alumno insertado al final correctamente.");
                    } else {
                        menu.mostrarMensaje(
                                "No se pudo insertar. Codigo duplicado.");
                    }

                    break;
                }

                // 3. INSERTAR EN POSICION X
                case 3: {

                    int posicion = menu.leerEntero(
                            "Ingrese la posicion donde insertar: ");

                    Alumno alumno = menu.leerAlumno();

                    if (lista.insertarPosicion(alumno, posicion)) {
                        menu.mostrarMensaje(
                                "Alumno insertado correctamente.");
                    } else {
                        menu.mostrarMensaje(
                                "No se pudo insertar. Verifique la posicion "
                                + "o el codigo.");
                    }

                    break;
                }

                // 4. INSERTAR POR REFERENCIA
                case 4: {

                    String referencia = menu.leerTexto(
                            "Ingrese el codigo de referencia: ");

                    Alumno alumno = menu.leerAlumno();

                    if (lista.insertarReferencia(referencia, alumno)) {
                        menu.mostrarMensaje(
                                "Alumno insertado despues de la referencia.");
                    } else {
                        menu.mostrarMensaje(
                                "No se pudo insertar. Verifique la referencia "
                                + "o el codigo.");
                    }

                    break;
                }

                // 5. ELIMINAR AL INICIO
                case 5: {

//                    Alumno eliminado = lista.eliminarInicio();
//
//                    if (eliminado != null) {
//                        menu.mostrarMensaje(
//                                "Alumno eliminado: " + eliminado);
//                    } else {
//                        menu.mostrarMensaje("La lista esta vacia.");
//                    }
//
//                    break;
                }

                // 6. ELIMINAR AL FINAL
                case 6: {

//                    Alumno eliminado = lista.eliminarFinal();
//
//                    if (eliminado != null) {
//                        menu.mostrarMensaje(
//                                "Alumno eliminado: " + eliminado);
//                    } else {
//                        menu.mostrarMensaje("La lista esta vacia.");
//                    }
//
//                    break;
                }

                // 7. ELIMINAR EN POSICION X
                case 7: {
//
//                    int posicion = menu.leerEntero(
//                            "Ingrese la posicion a eliminar: ");
//
//                    Alumno eliminado = lista.eliminarPosicion(posicion);
//
//                    if (eliminado != null) {
//                        menu.mostrarMensaje(
//                                "Alumno eliminado: " + eliminado);
//                    } else {
//                        menu.mostrarMensaje(
//                                "Posicion no valida o lista vacia.");
//                    }
//
//                    break;
                }

                // 8. ELIMINAR POR REFERENCIA
                case 8: {

//                    String codigo = menu.leerTexto(
//                            "Ingrese el codigo del alumno a eliminar: ");
//
//                    Alumno eliminado = lista.eliminarReferencia(codigo);
//
//                    if (eliminado != null) {
//                        menu.mostrarMensaje(
//                                "Alumno eliminado: " + eliminado);
//                    } else {
//                        menu.mostrarMensaje(
//                                "No se encontro el alumno.");
//                    }
//
//                    break;
                }

                // 9. BUSCAR ALUMNO
                case 9: {
//
//                    String codigo = menu.leerTexto(
//                            "Ingrese el codigo del alumno: ");
//
//                    Alumno alumno = lista.buscar(codigo);
//
//                    menu.mostrarAlumno(alumno);
//
//                    break;
                }

                // 10. RECORRER LISTA
                case 10: {

                    ArrayList<Alumno> alumnos = lista.recorrer();

                    menu.mostrarLista(alumnos);

                    break;
                }

                // 11. ORDENAR LISTA
                case 11: {
//
//                    lista.ordenar();
//
//                    menu.mostrarMensaje(
//                            "Lista ordenada por codigo ascendente.");
//
//                    menu.mostrarLista(lista.recorrer());
//
//                    break;
                }

                // 12. INTERCAMBIAR ELEMENTOS
                case 12: {
//
//                    int posicion1 = menu.leerEntero(
//                            "Ingrese la primera posicion: ");
//
//                    int posicion2 = menu.leerEntero(
//                            "Ingrese la segunda posicion: ");
//
//                    if (lista.intercambiar(posicion1, posicion2)) {
//
//                        menu.mostrarMensaje(
//                                "Elementos intercambiados correctamente.");
//
//                        menu.mostrarLista(lista.recorrer());
//
//                    } else {
//
//                        menu.mostrarMensaje(
//                                "No se pudo realizar el intercambio. "
//                                + "Verifique las posiciones.");
//                    }
//
//                    break;
                }

                // 13. OBTENER TAMANIO
                case 13: {
//
//                    menu.mostrarMensaje(
//                            "Cantidad de alumnos registrados: "
//                            + lista.getTamanio());
//
//                    break;
//                }
//
//                // 14. MODIFICAR ALUMNO
//                case 14: {
//
//                    String codigo = menu.leerTexto(
//                            "Ingrese el codigo del alumno a modificar: ");
//
//                    String nombres = menu.leerTexto(
//                            "Ingrese los nuevos nombres: ");
//
//                    String carrera = menu.leerTexto(
//                            "Ingrese la nueva carrera: ");
//
//                    int semestre;
//
//                    do {
//                        semestre = menu.leerEntero(
//                                "Ingrese el nuevo semestre: ");
//
//                        if (semestre < 1) {
//                            menu.mostrarMensaje(
//                                    "El semestre debe ser mayor que cero.");
//                        }
//
//                    } while (semestre < 1);
//
//                    if (lista.modificar(codigo, nombres,
//                            carrera, semestre)) {
//
//                        menu.mostrarMensaje(
//                                "Datos del alumno modificados correctamente.");
//
//                    } else {
//
//                        menu.mostrarMensaje(
//                                "No se encontro el alumno.");
//                    }
//
//                    break;
//                }
//
//                // SALIR
//                case 0: {
//
//                    menu.mostrarMensaje(
//                            "Gracias por utilizar el sistema.");
//
//                    break;
//                }
//
//                // OPCION INCORRECTA
//                default: {
//
//                    menu.mostrarMensaje(
//                            "Opcion incorrecta. Intente nuevamente.");
//
//                    break;
                }
            }

        } while (opcion != 0);
    }
}
