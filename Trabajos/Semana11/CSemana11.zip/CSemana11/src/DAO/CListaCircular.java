package DAO;

import Modelo.Alumno;
import Modelo.CNodo;
import java.util.ArrayList;

public class CListaCircular {

    private CNodo ultimo;
    private int tamanio;

    public CListaCircular() {
        ultimo = null;
        tamanio = 0;
    }

    // Verificar si la lista esta vacia
    public boolean estaVacia() {
        return ultimo == null;
    }

    // Verificar si el codigo ya existe
    private boolean existeCodigo(String codigo) {
        return buscar(codigo) != null;
    }

    // Obtener un nodo segun su posicion (inicia en 1)
    private CNodo obtenerNodo(int posicion) {

        if (posicion < 1 || posicion > tamanio) {
            return null;
        }

        CNodo actual = ultimo.getSiguiente();

        for (int i = 1; i < posicion; i++) {
            actual = actual.getSiguiente();
        }

        return actual;
    }

    // 1. INSERTAR AL INICIO
    public boolean insertarInicio(Alumno alumno) {

        if (alumno == null || existeCodigo(alumno.getCodigo())) {
            return false;
        }

        CNodo nuevo = new CNodo(alumno);

        if (estaVacia()) {
            nuevo.setSiguiente(nuevo);
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(ultimo.getSiguiente());
            ultimo.setSiguiente(nuevo);
        }

        tamanio++;
        return true;
    }

    // 2. INSERTAR AL FINAL
    public boolean insertarFinal(Alumno alumno) {

        if (alumno == null || existeCodigo(alumno.getCodigo())) {
            return false;
        }

        CNodo nuevo = new CNodo(alumno);

        if (estaVacia()) {
            nuevo.setSiguiente(nuevo);
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(ultimo.getSiguiente());
            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }

        tamanio++;
        return true;
    }

    // 3. INSERTAR EN UNA POSICION
    public boolean insertarPosicion(Alumno alumno, int posicion) {

        if (alumno == null || existeCodigo(alumno.getCodigo())
                || posicion < 1 || posicion > tamanio + 1) {
            return false;
        }

        if (posicion == 1) {
            return insertarInicio(alumno);
        }

        if (posicion == tamanio + 1) {
            return insertarFinal(alumno);
        }

        CNodo anterior = obtenerNodo(posicion - 1);
        CNodo nuevo = new CNodo(alumno);

        nuevo.setSiguiente(anterior.getSiguiente());
        anterior.setSiguiente(nuevo);

        tamanio++;
        return true;
    }

    // 4. INSERTAR POR REFERENCIA
    // Inserta despues del alumno indicado por su codigo
    public boolean insertarReferencia(String codigoReferencia,
                                     Alumno alumno) {

        if (alumno == null || existeCodigo(alumno.getCodigo())) {
            return false;
        }

        CNodo actual = buscarNodo(codigoReferencia);

        if (actual == null) {
            return false;
        }

        CNodo nuevo = new CNodo(alumno);

        nuevo.setSiguiente(actual.getSiguiente());
        actual.setSiguiente(nuevo);

        if (actual == ultimo) {
            ultimo = nuevo;
        }

        tamanio++;
        return true;
    }
    
        // BUSCAR UN NODO POR CODIGO
    private CNodo buscarNodo(String codigo) {

        if (estaVacia() || codigo == null) {
            return null;
        }

        CNodo actual = ultimo.getSiguiente();

        do {
            if (actual.getDato().getCodigo()
                    .equalsIgnoreCase(codigo)) {
                return actual;
            }

            actual = actual.getSiguiente();

        } while (actual != ultimo.getSiguiente());

        return null;
    }
    
        // 9. BUSCAR UN ALUMNO
    public Alumno buscar(String codigo) {

        CNodo nodo = buscarNodo(codigo);

        if (nodo != null) {
            return nodo.getDato();
        }

        return null;
    }
    
        // 10. RECORRER LA LISTA
    public ArrayList<Alumno> recorrer() {

        ArrayList<Alumno> alumnos = new ArrayList<>();

        if (estaVacia()) {
            return alumnos;
        }

        CNodo actual = ultimo.getSiguiente();

        do {
            alumnos.add(actual.getDato());
            actual = actual.getSiguiente();

        } while (actual != ultimo.getSiguiente());

        return alumnos;
    }

}
