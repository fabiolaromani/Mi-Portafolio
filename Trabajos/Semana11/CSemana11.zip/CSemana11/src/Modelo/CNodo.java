package Modelo;

public class CNodo {

    private Alumno dato;
    private CNodo siguiente;

    public CNodo(Alumno dato) {
        this.dato = dato;
        this.siguiente = null;
    }

    public Alumno getDato() {
        return dato;
    }

    public void setDato(Alumno dato) {
        this.dato = dato;
    }

    public CNodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(CNodo siguiente) {
        this.siguiente = siguiente;
    }
}
