package Vista;

import DAO.CListaCircularCentroMedico;
import Modelo.Paciente;
import java.util.ArrayList;

public class PrincipalCentroMedico {
    public static void main(String[] args) {
        CListaCircularCentroMedico lista = new CListaCircularCentroMedico();
        MenuCentroMedico menu = new MenuCentroMedico();
        int opcion;

        do {
            menu.mostrarMenu();
            opcion = menu.leerEntero("Seleccione una opción: ");

            switch (opcion) {
                case 1: {
                    Paciente p = menu.leerPaciente();
                    if (lista.registrarInicio(p)) {
                        menu.mostrarMensaje("Paciente registrado al inicio correctamente.");
                    } else {
                        menu.mostrarMensaje("Error: Código duplicado o datos inválidos.");
                    }
                    break;
                }
                case 2: {
                    Paciente p = menu.leerPaciente();
                    if (lista.registrarFinal(p)) {
                        menu.mostrarMensaje("Paciente registrado al final correctamente.");
                    } else {
                        menu.mostrarMensaje("Error: Código duplicado o datos inválidos.");
                    }
                    break;
                }
                case 3: {
                    int pos = menu.leerEntero("Ingrese la posición: ");
                    Paciente p = menu.leerPaciente();
                    if (lista.registrarEnPosicion(p, pos)) {
                        menu.mostrarMensaje("Paciente registrado en la posición " + pos + ".");
                    } else {
                        menu.mostrarMensaje("Error: Posición inválida o código duplicado.");
                    }
                    break;
                }
                case 4: {
                    String ref = menu.leerTexto("Ingrese el código del paciente de referencia: ");
                    Paciente p = menu.leerPaciente();
                    if (lista.registrarPorReferencia(ref, p)) {
                        menu.mostrarMensaje("Paciente registrado después de la referencia.");
                    } else {
                        menu.mostrarMensaje("Error: Referencia no encontrada o código duplicado.");
                    }
                    break;
                }
                case 5: {
                    Paciente atendido = lista.atenderSiguiente();
                    if (atendido != null) {
                        menu.mostrarMensaje("[ATENCIÓN MÉDICA] Pasando a consultorio: " + atendido);
                    } else {
                        menu.mostrarMensaje("La lista de espera está vacía.");
                    }
                    break;
                }
                case 6: {
                    String codigo = menu.leerTexto("Ingrese el código del paciente para cancelar turno: ");
                    Paciente cancelado = lista.eliminarPorCodigo(codigo);
                    if (cancelado != null) {
                        menu.mostrarMensaje("Turno cancelado para: " + cancelado);
                    } else {
                        menu.mostrarMensaje("No se encontró un paciente con ese código.");
                    }
                    break;
                }
                case 7: {
                    Paciente eliminado = lista.eliminarPrimerTurno();
                    if (eliminado != null) {
                        menu.mostrarMensaje("Primer turno eliminado: " + eliminado);
                    } else {
                        menu.mostrarMensaje("La lista está vacía.");
                    }
                    break;
                }
                case 8: {
                    Paciente eliminado = lista.eliminarUltimoTurno();
                    if (eliminado != null) {
                        menu.mostrarMensaje("Último turno eliminado: " + eliminado);
                    } else {
                        menu.mostrarMensaje("La lista está vacía.");
                    }
                    break;
                }
                case 9: {
                    String codigo = menu.leerTexto("Ingrese el código a buscar: ");
                    Paciente p = lista.buscar(codigo);
                    if (p != null) {
                        menu.mostrarMensaje("Paciente encontrado: " + p);
                    } else {
                        menu.mostrarMensaje("No se encontró el registro.");
                    }
                    break;
                }
                case 10: {
                    ArrayList<Paciente> pendientes = lista.listarPendientes();
                    menu.mostrarLista(pendientes);
                    break;
                }
                case 11: {
                    menu.mostrarMensaje("Cantidad total de pacientes en espera: " + lista.getTamanio());
                    break;
                }
                case 12: {
                    Paciente proximo = lista.consultarProximo();
                    if (proximo != null) {
                        menu.mostrarMensaje("Próximo turno a ser atendido: " + proximo);
                    } else {
                        menu.mostrarMensaje("No hay pacientes en espera.");
                    }
                    break;
                }
                case 13: {
                    lista.ordenarPacientes();
                    menu.mostrarMensaje("Pacientes ordenados correctamente por código.");
                    menu.mostrarLista(lista.listarPendientes());
                    break;
                }
                case 14: {
                    int p1 = menu.leerEntero("Ingrese la primera posición: ");
                    int p2 = menu.leerEntero("Ingrese la segunda posición: ");
                    if (lista.intercambiarPacientes(p1, p2)) {
                        menu.mostrarMensaje("Posiciones intercambiadas con éxito.");
                        menu.mostrarLista(lista.listarPendientes());
                    } else {
                        menu.mostrarMensaje("Error en el intercambio. Verifique las posiciones.");
                    }
                    break;
                }
                case 15: {
                    String codigo = menu.leerTexto("Ingrese el código del paciente a modificar: ");
                    String nombres = menu.leerTexto("Nuevos Nombres: ");
                    String apellidos = menu.leerTexto("Nuevos Apellidos: ");
                    String dni = menu.leerTexto("Nuevo DNI: ");
                    String especialidad = menu.leerTexto("Nueva Especialidad: ");
                    if (lista.modificarPaciente(codigo, nombres, apellidos, dni, especialidad)) {
                        menu.mostrarMensaje("Datos del paciente actualizados correctamente.");
                    } else {
                        menu.mostrarMensaje("No se encontró el paciente.");
                    }
                    break;
                }
                case 0: {
                    menu.mostrarMensaje("Saliendo del Sistema del Centro Médico...");
                    break;
                }
                default: {
                    menu.mostrarMensaje("Opción incorrecta. Intente nuevamente.");
                    break;
                }
            }
        } while (opcion != 0);
    }
}