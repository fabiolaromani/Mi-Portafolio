package Vista;

import Modelo.Paciente;
import java.util.ArrayList;
import java.util.Scanner;

public class MenuCentroMedico {
    private Scanner teclado;

    public MenuCentroMedico() {
        teclado = new Scanner(System.in);
    }

    public void mostrarMenu() {
        System.out.println("\n=================================================");
        System.out.println("   SISTEMA DE GESTIÓN DE TURNOS - CENTRO MÉDICO");
        System.out.println("   LISTA CIRCULAR SIMPLEMENTE ENLAZADA");
        System.out.println("=================================================");
        System.out.println("REGISTRO DE PACIENTES");
        System.out.println("1. Registrar paciente al inicio");
        System.out.println("2. Registrar paciente al final");
        System.out.println("3. Registrar paciente en posición X");
        System.out.println("4. Registrar paciente por referencia (después de código)");
        System.out.println("GESTIÓN DE TURNOS");
        System.out.println("5. Atender siguiente paciente");
        System.out.println("6. Cancelar turno por código de paciente");
        System.out.println("7. Eliminar primer turno pendiente");
        System.out.println("8. Eliminar último turno pendiente");
        System.out.println("CONSULTAS");
        System.out.println("9. Buscar paciente por código");
        System.out.println("10. Mostrar pacientes pendientes de atención");
        System.out.println("11. Consultar cantidad de pacientes registrados");
        System.out.println("12. Mostrar próximo paciente a atender");
        System.out.println("ADMINISTRACIÓN");
        System.out.println("13. Ordenar pacientes por código");
        System.out.println("14. Intercambiar posiciones de dos pacientes");
        System.out.println("15. Modificar datos de un paciente");
        System.out.println("0. Salir");
        System.out.println("=================================================");
    }

    public int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Error: Ingrese un número entero válido.");
            }
        }
    }

    public String leerTexto(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = teclado.nextLine().trim();
            if (!texto.isEmpty()) return texto;
            System.out.println("El campo no puede estar vacío.");
        }
    }

    public Paciente leerPaciente() {
        System.out.println("\n--- DATOS DEL PACIENTE ---");
        String codigo = leerTexto("Ingrese Código/Turno: ");
        String nombres = leerTexto("Ingrese Nombres: ");
        String apellidos = leerTexto("Ingrese Apellidos: ");
        String dni = leerTexto("Ingrese DNI: ");
        String especialidad = leerTexto("Ingrese Especialidad Médica: ");
        return new Paciente(codigo, nombres, apellidos, dni, especialidad);
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println("\n" + mensaje);
    }

    public void mostrarLista(ArrayList<Paciente> pacientes) {
        if (pacientes.isEmpty()) {
            System.out.println("\nNo hay pacientes pendientes en la lista.");
            return;
        }
        System.out.println("\n========== PACIENTES PENDIENTES ==========");
        int pos = 1;
        for (Paciente p : pacientes) {
            System.out.println("Posición " + pos + " -> " + p);
            pos++;
        }
        System.out.println("Total en espera: " + pacientes.size());
    }
}