package DAO;

import Modelo.Paciente;
import Modelo.CNodo;
import java.util.ArrayList;

public class CListaCircularCentroMedico {
    private CNodo ultimo;
    private int tamanio;

    public CListaCircularCentroMedico() {
        this.ultimo = null;
        this.tamanio = 0;
    }

    public boolean estaVacia() {
        return ultimo == null;
    }

    public int getTamanio() {
        return tamanio;
    }

    public boolean existeCodigo(String codigo) {
        return buscar(codigo) != null;
    }

    private CNodo obtenerNodo(int posicion) {
        if (posicion < 1 || posicion > tamanio) {
            return null;
        }
        CNodo actual = ultimo.getSiguiente();
        for (int i = 1; i < posicion; i++) {
            actual = actual.getSiguiente();
        }
        return actual;
    }

    // A.1. Registrar un paciente al inicio
    public boolean registrarInicio(Paciente paciente) {
        if (paciente == null || existeCodigo(paciente.getCodigo())) {
            return false;
        }
        CNodo nuevo = new CNodo(paciente);
        if (estaVacia()) {
            nuevo.setSiguiente(nuevo);
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(ultimo.getSiguiente());
            ultimo.setSiguiente(nuevo);
        }
        tamanio++;
        return true;
    }

    // A.2. Registrar un paciente al final
    public boolean registrarFinal(Paciente paciente) {
        if (paciente == null || existeCodigo(paciente.getCodigo())) {
            return false;
        }
        CNodo nuevo = new CNodo(paciente);
        if (estaVacia()) {
            nuevo.setSiguiente(nuevo);
            ultimo = nuevo;
        } else {
            nuevo.setSiguiente(ultimo.getSiguiente());
            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }
        tamanio++;
        return true;
    }

    // A.3. Insertar un paciente en una posición determinada
    public boolean registrarEnPosicion(Paciente paciente, int posicion) {
        if (paciente == null || existeCodigo(paciente.getCodigo()) || posicion < 1 || posicion > tamanio + 1) {
            return false;
        }
        if (posicion == 1) return registrarInicio(paciente);
        if (posicion == tamanio + 1) return registrarFinal(paciente);

        CNodo anterior = obtenerNodo(posicion - 1);
        CNodo nuevo = new CNodo(paciente);
        nuevo.setSiguiente(anterior.getSiguiente());
        anterior.setSiguiente(nuevo);
        tamanio++;
        return true;
    }

    // A.4. Insertar un paciente después de otro identificado por su código
    public boolean registrarPorReferencia(String codigoRef, Paciente paciente) {
        if (paciente == null || existeCodigo(paciente.getCodigo())) {
            return false;
        }
        CNodo actual = buscarNodo(codigoRef);
        if (actual == null) return false;

        CNodo nuevo = new CNodo(paciente);
        nuevo.setSiguiente(actual.getSiguiente());
        actual.setSiguiente(nuevo);
        if (actual == ultimo) {
            ultimo = nuevo;
        }
        tamanio++;
        return true;
    }

    private CNodo buscarNodo(String codigo) {
        if (estaVacia() || codigo == null) return null;
        CNodo actual = ultimo.getSiguiente();
        do {
            if (actual.getDato().getCodigo().equalsIgnoreCase(codigo)) {
                return actual;
            }
            actual = actual.getSiguiente();
        } while (actual != ultimo.getSiguiente());
        return null;
    }

    // B.1. Atender al siguiente paciente de la lista (Elimina y retorna el primero)
    public Paciente atenderSiguiente() {
        if (estaVacia()) return null;
        CNodo primero = ultimo.getSiguiente();
        Paciente atendido = primero.getDato();

        if (ultimo == primero) {
            ultimo = null;
        } else {
            ultimo.setSiguiente(primero.getSiguiente());
        }
        tamanio--;
        return atendido;
    }

    // B.2. Eliminar un turno cancelado por código de paciente
    public Paciente eliminarPorCodigo(String codigo) {
        if (estaVacia() || codigo == null) return null;
        CNodo primero = ultimo.getSiguiente();
        CNodo actual = primero;
        CNodo anterior = ultimo;

        do {
            if (actual.getDato().getCodigo().equalsIgnoreCase(codigo)) {
                Paciente eliminado = actual.getDato();
                if (tamanio == 1) {
                    ultimo = null;
                } else {
                    anterior.setSiguiente(actual.getSiguiente());
                    if (actual == ultimo) {
                        ultimo = anterior;
                    }
                }
                tamanio--;
                return eliminado;
            }
            anterior = actual;
            actual = actual.getSiguiente();
        } while (actual != primero);

        return null;
    }

    // B.3. Eliminar el primer turno pendiente
    public Paciente eliminarPrimerTurno() {
        return atenderSiguiente();
    }

    // B.4. Eliminar el último turno pendiente
    public Paciente eliminarUltimoTurno() {
        if (estaVacia()) return null;
        CNodo primero = ultimo.getSiguiente();
        Paciente eliminado = ultimo.getDato();

        if (ultimo == primero) {
            ultimo = null;
        } else {
            CNodo actual = primero;
            while (actual.getSiguiente() != ultimo) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(primero);
            ultimo = actual;
        }
        tamanio--;
        return eliminado;
    }

    // C.1. Buscar un paciente por su código
    public Paciente buscar(String codigo) {
        CNodo nodo = buscarNodo(codigo);
        return (nodo != null) ? nodo.getDato() : null;
    }

    // C.2. Mostrar todos los pacientes pendientes de atención
    public ArrayList<Paciente> listarPendientes() {
        ArrayList<Paciente> lista = new ArrayList<>();
        if (estaVacia()) return lista;
        CNodo actual = ultimo.getSiguiente();
        do {
            lista.add(actual.getDato());
            actual = actual.getSiguiente();
        } while (actual != ultimo.getSiguiente());
        return lista;
    }

    // C.4. Mostrar los datos del paciente que será atendido próximamente (Peek)
    public Paciente consultarProximo() {
        if (estaVacia()) return null;
        return ultimo.getSiguiente().getDato();
    }

    // D.1. Ordenar los pacientes según su código de turno/identificación
    public void ordenarPacientes() {
        if (tamanio <= 1) return;
        boolean cambiado;
        do {
            cambiado = false;
            CNodo actual = ultimo.getSiguiente();
            for (int i = 0; i < tamanio - 1; i++) {
                CNodo siguienteNodo = actual.getSiguiente();
                if (actual.getDato().getCodigo().compareToIgnoreCase(siguienteNodo.getDato().getCodigo()) > 0) {
                    Paciente temp = actual.getDato();
                    actual.setDato(siguienteNodo.getDato());
                    siguienteNodo.setDato(temp);
                    cambiado = true;
                }
                actual = actual.getSiguiente();
            }
        } while (cambiado);
    }

    // D.2. Intercambiar las posiciones de dos pacientes
    public boolean intercambiarPacientes(int pos1, int pos2) {
        if (pos1 < 1 || pos1 > tamanio || pos2 < 1 || pos2 > tamanio || pos1 == pos2) {
            return false;
        }
        CNodo nodo1 = obtenerNodo(pos1);
        CNodo nodo2 = obtenerNodo(pos2);
        Paciente temp = nodo1.getDato();
        nodo1.setDato(nodo2.getDato());
        nodo2.setDato(temp);
        return true;
    }

    // D.3. Modificar los datos de un paciente
    public boolean modificarPaciente(String codigo, String nombres, String apellidos, String dni, String especialidad) {
        CNodo nodo = buscarNodo(codigo);
        if (nodo == null) return false;
        Paciente p = nodo.getDato();
        p.setNombres(nombres);
        p.setApellidos(apellidos);
        p.setDni(dni);
        p.setEspecialidad(especialidad);
        return true;
    }
}