package Modelo;

public class Paciente {
    private String codigo;
    private String nombres;
    private String apellidos;
    private String dni;
    private String especialidad;

    public Paciente() {
    }

    public Paciente(String codigo, String nombres, String apellidos, String dni, String especialidad) {
        this.codigo = codigo;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.dni = dni;
        this.especialidad = especialidad;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    @Override
    public String toString() {
        return "[Código: " + codigo + "] | Paciente: " + nombres + " " + apellidos + 
               " | DNI: " + dni + " | Especialidad: " + especialidad;
    }
}