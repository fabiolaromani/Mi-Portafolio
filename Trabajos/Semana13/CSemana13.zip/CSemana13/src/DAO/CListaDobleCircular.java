package DAO;

import Modelo.Alumno;
import Modelo.CNodo;

public class CListaDobleCircular {
    private CNodo Cabeza;
    private CNodo Cola;
    private int Tamano;

    public CListaDobleCircular() {
        this.Cabeza = null;
        this.Cola = null;
        this.Tamano = 0;
    }

    // 1. Verificar si la lista está vacía
    public boolean estaVacia() {
        return Cabeza == null;
    }

    // 2. Obtener el tamaño actual de la lista
    public int obtenerTamano() {
        return Tamano;
    }

    // 3. Insertar al inicio de la lista circular doblemente enlazada
    public void insertarInicio(Alumno alumno) {
        CNodo nuevo = new CNodo(alumno);

        if (estaVacia()) {
            Cabeza = nuevo;
            Cola = nuevo;
            Cabeza.setSiguiente(Cabeza);
            Cabeza.setAnterior(Cabeza);
        } else {
            nuevo.setSiguiente(Cabeza);
            nuevo.setAnterior(Cola);
            Cabeza.setAnterior(nuevo);
            Cola.setSiguiente(nuevo);
            Cabeza = nuevo;
        }
        Tamano++;
    }

    // 4. Insertar al final de la lista circular doblemente enlazada
    public void insertarFinal(Alumno alumno) {
        if (estaVacia()) {
            insertarInicio(alumno);
            return;
        }

        CNodo nuevo = new CNodo(alumno);
        nuevo.setAnterior(Cola);
        nuevo.setSiguiente(Cabeza);
        Cola.setSiguiente(nuevo);
        Cabeza.setAnterior(nuevo);
        Cola = nuevo;
        Tamano++;
    }

    // 5. Insertar en una posición específica (0 hasta Tamano)
    public boolean insertarEnPosicion(int posicion, Alumno alumno) {
        if (posicion < 0 || posicion > Tamano) {
            return false;
        }
        if (posicion == 0) {
            insertarInicio(alumno);
            return true;
        }
        if (posicion == Tamano) {
            insertarFinal(alumno);
            return true;
        }

        CNodo actual = Cabeza;
        for (int i = 0; i < posicion; i++) {
            actual = actual.getSiguiente();
        }

        CNodo anteriorNodo = actual.getAnterior();
        CNodo nuevo = new CNodo(alumno);

        nuevo.setAnterior(anteriorNodo);
        nuevo.setSiguiente(actual);
        anteriorNodo.setSiguiente(nuevo);
        actual.setAnterior(nuevo);
        Tamano++;
        return true;
    }

    // 6. Eliminar el primer nodo (Cabeza)
    public Alumno eliminarInicio() {
        if (estaVacia()) {
            return null;
        }

        Alumno eliminado = Cabeza.getDato();

        if (Tamano == 1) {
            Cabeza = null;
            Cola = null;
        } else {
            Cabeza = Cabeza.getSiguiente();
            Cabeza.setAnterior(Cola);
            Cola.setSiguiente(Cabeza);
        }
        Tamano--;
        return eliminado;
    }

    // 7. Eliminar el último nodo (Cola)
    public Alumno eliminarFinal() {
        if (estaVacia()) {
            return null;
        }
        if (Tamano == 1) {
            return eliminarInicio();
        }

        Alumno eliminado = Cola.getDato();
        Cola = Cola.getAnterior();
        Cola.setSiguiente(Cabeza);
        Cabeza.setAnterior(Cola);
        Tamano--;
        return eliminado;
    }

    // 8. Eliminar un alumno buscando por su código
    public boolean eliminarPorCodigo(int codigo) {
        if (estaVacia()) {
            return false;
        }

        CNodo actual = Cabeza;
        for (int i = 0; i < Tamano; i++) {
            if (actual.getDato().getCodigo() == codigo) {
                if (actual == Cabeza) {
                    eliminarInicio();
                } else if (actual == Cola) {
                    eliminarFinal();
                } else {
                    actual.getAnterior().setSiguiente(actual.getSiguiente());
                    actual.getSiguiente().setAnterior(actual.getAnterior());
                    Tamano--;
                }
                return true;
            }
            actual = actual.getSiguiente();
        }
        return false;
    }

    // 9. Buscar un alumno por su código
    public Alumno buscarPorCodigo(int codigo) {
        if (estaVacia()) {
            return null;
        }

        CNodo actual = Cabeza;
        for (int i = 0; i < Tamano; i++) {
            if (actual.getDato().getCodigo() == codigo) {
                return actual.getDato();
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    // 10. Actualizar notas de un alumno (recálculo automático del promedio)
    public boolean actualizarNotas(int codigo, int nuevaNota1, int nuevaNota2) {
        Alumno encontrado = buscarPorCodigo(codigo);
        if (encontrado == null) {
            return false;
        }
        encontrado.setNota1(nuevaNota1);
        encontrado.setNota2(nuevaNota2);
        return true;
    }
    
    // 11. Mostrar todos los alumnos avanzando (Cabeza -> Cola -> Cabeza)
    public void mostrarAdelante() {
        if (estaVacia()) {
            System.out.println("La lista está vacía.");
            return;
        }
        CNodo actual = Cabeza;
        for (int i = 0; i < Tamano; i++) {
            System.out.println((i + 1) + ". " + actual.getDato());
            actual = actual.getSiguiente();
        }
    }

    // 12. Mostrar todos los alumnos retrocediendo (Cola -> Cabeza -> Cola)
    public void mostrarAtras() {
        if (estaVacia()) {
            System.out.println("La lista está vacía.");
            return;
        }
        CNodo actual = Cola;
        for (int i = 0; i < Tamano; i++) {
            System.out.println((i + 1) + ". " + actual.getDato());
            actual = actual.getAnterior();
        }
    }

    // 13. Obtener el primer alumno (Cabeza)
    public Alumno obtenerPrimero() {
        return estaVacia() ? null : Cabeza.getDato();
    }

    // 14. Obtener el último alumno (Cola)
    public Alumno obtenerUltimo() {
        return estaVacia() ? null : Cola.getDato();
    }

    // 15. Limpiar / vaciar toda la lista
    public void limpiarLista() {
        Cabeza = null;
        Cola = null;
        Tamano = 0;
    }

    // 16. Ordenar nodos de mayor a menor promedio (intercambiando el dato Alumno)
    public void ordenarPorPromedioDesc() {
        if (Tamano < 2) {
            return;
        }
        for (int i = 0; i < Tamano - 1; i++) {
            CNodo actual = Cabeza;
            for (int j = 0; j < Tamano - 1 - i; j++) {
                CNodo siguienteNodo = actual.getSiguiente();
                if (actual.getDato().getPromedio() < siguienteNodo.getDato().getPromedio()) {
                    Alumno temp = actual.getDato();
                    actual.setDato(siguienteNodo.getDato());
                    siguienteNodo.setDato(temp);
                }
                actual = siguienteNodo;
            }
        }
    }

    // 17. Hallar el promedio general de todos los alumnos[cite: 4]
    public float hallarPromedio() {
        if (estaVacia()) {
            return 0.0f;
        }
        float suma = 0.0f;
        CNodo actual = Cabeza;
        for (int i = 0; i < Tamano; i++) {
            suma += actual.getDato().getPromedio();
            actual = actual.getSiguiente();
        }
        return suma / Tamano;
    }

    // 18. Listar / mostrar alumnos aprobados (promedio >= 10.5)[cite: 4]
    public int alumnosAprobados() {
        if (estaVacia()) {
            System.out.println("No hay alumnos registrados.");
            return 0;
        }
        int contador = 0;
        CNodo actual = Cabeza;
        for (int i = 0; i < Tamano; i++) {
            Alumno al = actual.getDato();
            if (al.getPromedio() >= 10.5f) {
                System.out.println(al);
                contador++;
            }
            actual = actual.getSiguiente();
        }
        return contador;
    }

    // 19. Listar / mostrar alumnos desaprobados (promedio < 10.5)[cite: 4]
    public int alumnosDesaprobados() {
        if (estaVacia()) {
            System.out.println("No hay alumnos registrados.");
            return 0;
        }
        int contador = 0;
        CNodo actual = Cabeza;
        for (int i = 0; i < Tamano; i++) {
            Alumno al = actual.getDato();
            if (al.getPromedio() < 10.5f) {
                System.out.println(al);
                contador++;
            }
            actual = actual.getSiguiente();
        }
        return contador;
    }

    // 20. Obtener el alumno con mayor promedio
    public Alumno alumnoMayorPromedio() {
        if (estaVacia()) {
            return null;
        }
        Alumno mayor = Cabeza.getDato();
        CNodo actual = Cabeza.getSiguiente();
        for (int i = 1; i < Tamano; i++) {
            if (actual.getDato().getPromedio() > mayor.getPromedio()) {
                mayor = actual.getDato();
            }
            actual = actual.getSiguiente();
        }
        return mayor;
    }
}