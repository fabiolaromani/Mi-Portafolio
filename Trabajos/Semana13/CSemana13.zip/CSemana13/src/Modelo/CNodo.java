package Modelo;

public class CNodo {
    private Alumno dato;
    private CNodo anterior;
    private CNodo siguiente;

    public CNodo(Alumno dato) {
        this.dato = dato;
        this.anterior = null;
        this.siguiente = null;
    }

    public Alumno getDato() {
        return dato;
    }

    public void setDato(Alumno dato) {
        this.dato = dato;
    }

    public CNodo getAnterior() {
        return anterior;
    }

    public void setAnterior(CNodo anterior) {
        this.anterior = anterior;
    }

    public CNodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(CNodo siguiente) {
        this.siguiente = siguiente;
    }
}