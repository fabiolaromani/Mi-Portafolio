package Modelo;

public class Alumno {
    private int codigo;
    private String nombre;
    private int nota1;
    private int nota2;
    private float promedio;

    public Alumno() {
    }

    public Alumno(int codigo, String nombre, int nota1, int nota2) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.nota1 = nota1;
        this.nota2 = nota2;
        calcularPromedio();
    }

    public void calcularPromedio() {
        this.promedio = (this.nota1 + this.nota2) / 2.0f;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNota1() {
        return nota1;
    }

    public void setNota1(int nota1) {
        this.nota1 = nota1;
        calcularPromedio();
    }

    public int getNota2() {
        return nota2;
    }

    public void setNota2(int nota2) {
        this.nota2 = nota2;
        calcularPromedio();
    }

    public float getPromedio() {
        return promedio;
    }

    @Override
    public String toString() {
        return String.format(
            "Código: %d | Nombre: %-15s | N1: %d | N2: %d | Promedio: %.2f",
            codigo, nombre, nota1, nota2, promedio
        );
    }
}