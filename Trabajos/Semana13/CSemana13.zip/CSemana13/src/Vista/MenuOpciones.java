package Vista;

import DAO.CListaDobleCircular;
import Modelo.Alumno;
import java.util.Scanner;

public class MenuOpciones {
    private final CListaDobleCircular lista;
    private final Scanner sc;

    public MenuOpciones() {
        this.lista = new CListaDobleCircular();
        this.sc = new Scanner(System.in);
    }

    public void iniciar() {
        int opcion;
        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");
            procesarOpcion(opcion);
        } while (opcion != 0);
    }

    private void mostrarMenu() {
        System.out.println("\n=======================================================");
        System.out.println("   SEMANA 13 - LISTA CIRCULAR DOBLEMENTE ENLAZADA");
        System.out.println("=======================================================");
        System.out.println(" 1. Verificar si está vacía          11. Mostrar adelante");
        System.out.println(" 2. Obtener tamaño                   12. Mostrar atrás");
        System.out.println(" 3. Insertar al inicio               13. Obtener primero (Cabeza)");
        System.out.println(" 4. Insertar al final                14. Obtener último (Cola)");
        System.out.println(" 5. Insertar en posición             15. Limpiar lista");
        System.out.println(" 6. Eliminar al inicio               16. Ordenar por promedio desc.");
        System.out.println(" 7. Eliminar al final                17. Hallar promedio general");
        System.out.println(" 8. Eliminar por código              18. Alumnos aprobados");
        System.out.println(" 9. Buscar por código                19. Alumnos desaprobados");
        System.out.println("10. Actualizar notas                 20. Alumno con mayor promedio");
        System.out.println(" 0. Salir");
        System.out.println("=======================================================");
    }

    private void procesarOpcion(int opcion) {
        switch (opcion) {
            case 1 -> System.out.println(lista.estaVacia()
                    ? "La lista está VACÍA."
                    : "La lista contiene elementos.");

            case 2 -> System.out.println("Tamaño actual: " + lista.obtenerTamano() + " alumno(s).");

            case 3 -> {
                lista.insertarInicio(leerAlumno());
                System.out.println("Alumno insertado al inicio.");
            }

            case 4 -> {
                lista.insertarFinal(leerAlumno());
                System.out.println("Alumno insertado al final.");
            }

            case 5 -> {
                int pos = leerEntero("Ingrese posición (0 a " + lista.obtenerTamano() + "): ");
                Alumno al = leerAlumno();
                System.out.println(lista.insertarEnPosicion(pos, al)
                        ? "Alumno insertado en la posición " + pos + "."
                        : "Posición inválida.");
            }

            case 6 -> {
                Alumno elim = lista.eliminarInicio();
                System.out.println(elim != null
                        ? "Eliminado del inicio: " + elim
                        : "La lista está vacía.");
            }

            case 7 -> {
                Alumno elim = lista.eliminarFinal();
                System.out.println(elim != null
                        ? "Eliminado del final: " + elim
                        : "La lista está vacía.");
            }

            case 8 -> {
                int cod = leerEntero("Código del alumno a eliminar: ");
                System.out.println(lista.eliminarPorCodigo(cod)
                        ? "Alumno eliminado correctamente."
                        : "No se encontró un alumno con ese código.");
            }

            case 9 -> {
                int cod = leerEntero("Código del alumno a buscar: ");
                Alumno encontrado = lista.buscarPorCodigo(cod);
                System.out.println(encontrado != null
                        ? "Encontrado -> " + encontrado
                        : "Alumno no encontrado.");
            }

            case 10 -> {
                int cod = leerEntero("Código del alumno a actualizar: ");
                int n1 = leerNota("Nueva Nota 1 (0-20): ");
                int n2 = leerNota("Nueva Nota 2 (0-20): ");
                System.out.println(lista.actualizarNotas(cod, n1, n2)
                        ? "Notas y promedio actualizados."
                        : "No se encontró el código indicado.");
            }

            case 11 -> {
                System.out.println("\n--- RECORRIDO ADELANTE (Cabeza -> Cola) ---");
                lista.mostrarAdelante();
            }

            case 12 -> {
                System.out.println("\n--- RECORRIDO ATRÁS (Cola -> Cabeza) ---");
                lista.mostrarAtras();
            }

            case 13 -> {
                Alumno primero = lista.obtenerPrimero();
                System.out.println(primero != null
                        ? "Cabeza -> " + primero
                        : "La lista está vacía.");
            }

            case 14 -> {
                Alumno ultimo = lista.obtenerUltimo();
                System.out.println(ultimo != null
                        ? "Cola -> " + ultimo
                        : "La lista está vacía.");
            }

            case 15 -> {
                lista.limpiarLista();
                System.out.println("Lista vaciada completamente.");
            }

            case 16 -> {
                lista.ordenarPorPromedioDesc();
                System.out.println("Lista ordenada de mayor a menor promedio.");
                lista.mostrarAdelante();
            }

            case 17 -> System.out.printf("Promedio general del aula: %.2f%n", lista.hallarPromedio());

            case 18 -> {
                System.out.println("\n--- ALUMNOS APROBADOS ---");
                int cant = lista.alumnosAprobados();
                System.out.println("Total aprobados: " + cant);
            }

            case 19 -> {
                System.out.println("\n--- ALUMNOS DESAPROBADOS ---");
                int cant = lista.alumnosDesaprobados();
                System.out.println("Total desaprobados: " + cant);
            }

            case 20 -> {
                Alumno mejor = lista.alumnoMayorPromedio();
                System.out.println(mejor != null
                        ? "Mayor promedio -> " + mejor
                        : "La lista está vacía.");
            }

            case 0 -> System.out.println("Saliendo del sistema...");

            default -> System.out.println("Opción no válida. Intente nuevamente.");
        }
    }

    private Alumno leerAlumno() {
        int codigo = leerEntero("Código: ");
        System.out.print("Nombre: ");
        String nombre = sc.nextLine().trim();
        int nota1 = leerNota("Nota 1 (0-20): ");
        int nota2 = leerNota("Nota 2 (0-20): ");
        return new Alumno(codigo, nombre, nota1, nota2);
    }

    private int leerEntero(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Error: ingrese un número entero válido.");
            }
        }
    }

    private int leerNota(String mensaje) {
        while (true) {
            int nota = leerEntero(mensaje);
            if (nota >= 0 && nota <= 20) {
                return nota;
            }
            System.out.println("Error: la nota debe estar entre 0 y 20.");
        }
    }
}